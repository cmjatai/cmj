self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d44ac6d2a43c55274f04d4c050ed0692",
    "url": "/static/v2025/brasao/brasao_1024.png"
  },
  {
    "revision": "8f99e5ea64db3fcda01b117954e4af6f",
    "url": "/static/v2025/brasao/brasao_128.png"
  },
  {
    "revision": "6c307cb29fb97f80facd4199fb46d45f",
    "url": "/static/v2025/brasao/brasao_256.png"
  },
  {
    "revision": "2faeef56500a910abf40dd2d98ef9a99",
    "url": "/static/v2025/brasao/brasao_32.png"
  },
  {
    "revision": "7f74a84703400cee7e6807673fd939f8",
    "url": "/static/v2025/brasao/brasao_512.png"
  },
  {
    "revision": "f7b796ce23a9c65a82e199e56efded11",
    "url": "/static/v2025/brasao/brasao_64.png"
  },
  {
    "revision": "af0481c7b1c5abcdd249eccd2092870c",
    "url": "/static/v2025/brasao/escola_1024.png"
  },
  {
    "revision": "7dff63695e03670336c6802fba347192",
    "url": "/static/v2025/img/arrow.png"
  },
  {
    "revision": "0e297f93ffa296cb2bf2782aa94e3268",
    "url": "/static/v2025/img/authenticated.png"
  },
  {
    "revision": "f0ce5b4a7afbc34f6a5b5451a18240a1",
    "url": "/static/v2025/img/avatar.png"
  },
  {
    "revision": "0fedfc17af66cfcd0beaab4a2beec61d",
    "url": "/static/v2025/img/beta.png"
  },
  {
    "revision": "4c35c324fbeb89c16b575c7381f70d6a",
    "url": "/static/v2025/img/bg.png"
  },
  {
    "revision": "39bca038c6e5e11e4f7c1e4ee3389c57",
    "url": "/static/v2025/img/bg_cmj_topo_menu_box_left.png"
  },
  {
    "revision": "e107ac1f05c9ef2c6c629807be229781",
    "url": "/static/v2025/img/bg_cmj_topo_menu_box_right.png"
  },
  {
    "revision": "849c15ec220a24e99aa8506601f41ba9",
    "url": "/static/v2025/img/brasao_transp.gif"
  },
  {
    "revision": "bb1e0825d5223704d2c295f4e1d86b91",
    "url": "/static/v2025/img/down_arrow_select.jpg"
  },
  {
    "revision": "587404969e0999831266a637b48aea4c",
    "url": "/static/v2025/img/etiqueta.png"
  },
  {
    "revision": "93ba768be99c67b9030dfa2ed3fff325",
    "url": "/static/v2025/img/file.png"
  },
  {
    "revision": "1eb0982bb8b20b77fafda393ae98e76b",
    "url": "/static/v2025/img/foto_aerea_camara_paisagem.jpg"
  },
  {
    "revision": "6fe0dd25f631b39eb6c052e6e43f8177",
    "url": "/static/v2025/img/foto_aerea_camara_retrato.jpg"
  },
  {
    "revision": "cfce175ac693569944dcba9e6c556dcf",
    "url": "/static/v2025/img/foto_chao_camara_paisagem.jpg"
  },
  {
    "revision": "ffe462fdcbc1b3fe6c152bbe9f0b3512",
    "url": "/static/v2025/img/foto_chao_camara_retrato.jpg"
  },
  {
    "revision": "64400f9f98b710c7fd5fd5fe737fa5da",
    "url": "/static/v2025/img/hand-note.png"
  },
  {
    "revision": "02a478243475dc9ba11c7f0915cfeb4b",
    "url": "/static/v2025/img/icon_comissoes.png"
  },
  {
    "revision": "40757133ae49b1a803785cd3b4d291d2",
    "url": "/static/v2025/img/icon_delete_white.png"
  },
  {
    "revision": "717405792fc232b5e210975822cac408",
    "url": "/static/v2025/img/icon_diario_oficial.png"
  },
  {
    "revision": "dbd3da2407bbb56f28b74d0ac573786d",
    "url": "/static/v2025/img/icon_facebook64x64.png"
  },
  {
    "revision": "c55a1bc2d99244a4c08aa448f361977b",
    "url": "/static/v2025/img/icon_instagram64x64.png"
  },
  {
    "revision": "db910d5dc2b1d30e05766228256eb03d",
    "url": "/static/v2025/img/icon_licitacao.png"
  },
  {
    "revision": "69067c48fb437e151a2f90d2290a70ee",
    "url": "/static/v2025/img/icon_materia_legislativa.png"
  },
  {
    "revision": "d9d48b974febd617d01b336974c30602",
    "url": "/static/v2025/img/icon_mesa_diretora.png"
  },
  {
    "revision": "52266702cd5f7dbdfa8024e799064a52",
    "url": "/static/v2025/img/icon_normas_juridicas.png"
  },
  {
    "revision": "d0c2cc179ab932fb24ea6258f61e6157",
    "url": "/static/v2025/img/icon_normas_juridicas_destaque.png"
  },
  {
    "revision": "aa171389861a663655fd834079f0d039",
    "url": "/static/v2025/img/icon_parlamentares.png"
  },
  {
    "revision": "0558a63d676cc435f2695119e12fdf5f",
    "url": "/static/v2025/img/icon_pautas.png"
  },
  {
    "revision": "f182e226a4ff6fe9408b616b02357cf0",
    "url": "/static/v2025/img/icon_plenarias.png"
  },
  {
    "revision": "02f6e0c106f20a7c6e21a7b523207f47",
    "url": "/static/v2025/img/icon_relatorios.png"
  },
  {
    "revision": "80baf13f86d26f847f3d1b7c7824d4ac",
    "url": "/static/v2025/img/icon_save_white.png"
  },
  {
    "revision": "c79840b15ffb49df44967f48807086b3",
    "url": "/static/v2025/img/icon_telegram64x64.png"
  },
  {
    "revision": "1d5eeaaa12bce45bbff08db8649e8236",
    "url": "/static/v2025/img/icon_transparencia.png"
  },
  {
    "revision": "ef54a640a5c60454a2e7453400bb474f",
    "url": "/static/v2025/img/icon_transparencia_prata.png"
  },
  {
    "revision": "2913dd0f6f0cb6715bccef36b0a1e834",
    "url": "/static/v2025/img/icon_twitter64x64.png"
  },
  {
    "revision": "aeb805abec46d148aad293ef9abffb79",
    "url": "/static/v2025/img/icon_whatsapp64x64.png"
  },
  {
    "revision": "014534399a6fb8befff55baa41e88f40",
    "url": "/static/v2025/img/icon_x_twitter.png"
  },
  {
    "revision": "f8e6bc697c257aa4fb5240c7dcbc97c4",
    "url": "/static/v2025/img/icon_x_twitter.svg"
  },
  {
    "revision": "c2e9627ea8ba42292971f91003af2490",
    "url": "/static/v2025/img/lexml.gif"
  },
  {
    "revision": "91a31efd0faa6d218e52775620e5280e",
    "url": "/static/v2025/img/logo.png"
  },
  {
    "revision": "8f99e5ea64db3fcda01b117954e4af6f",
    "url": "/static/v2025/img/logo_128.png"
  },
  {
    "revision": "317993f5074301653849e01d7650b1b3",
    "url": "/static/v2025/img/logo_cc.png"
  },
  {
    "revision": "06a3dea855d83cb8194e22ab2eabe198",
    "url": "/static/v2025/img/logo_cmj_redesocial.jpg"
  },
  {
    "revision": "59f2f9287bac78d247507ee5c5053dea",
    "url": "/static/v2025/img/logo_interlegis.png"
  },
  {
    "revision": "09e89b66eeb6647dece0197619aec778",
    "url": "/static/v2025/img/logo_portaldocidadao.png"
  },
  {
    "revision": "a1a5cb8ccda80ba8d2e53de044a749a0",
    "url": "/static/v2025/img/logo_sic.png"
  },
  {
    "revision": "8fbc3fa26d7f696fed113c2e72419a02",
    "url": "/static/v2025/img/manual.png"
  },
  {
    "revision": "1f22f15a76c2fd509eadcecc9e9c2b02",
    "url": "/static/v2025/img/pdf_cabec.jpg"
  },
  {
    "revision": "e86d4f3790dcba9d471b7d6ece42e48c",
    "url": "/static/v2025/img/pdf_cabec_margem.jpg"
  },
  {
    "revision": "c0e894ed8b441b6739133c2a7601150d",
    "url": "/static/v2025/img/pdf_rodape.jpg"
  },
  {
    "revision": "64679dab3b056be7ac0c73409f963fcb",
    "url": "/static/v2025/img/pdf_rodape_margem.jpg"
  },
  {
    "revision": "fb71e48b2330408afac41e0bcfbbd4c0",
    "url": "/static/v2025/img/pdflogo.png"
  },
  {
    "revision": "394e657c181354ac1b5c43ce799909a6",
    "url": "/static/v2025/img/perfil.1.jpg"
  },
  {
    "revision": "394e657c181354ac1b5c43ce799909a6",
    "url": "/static/v2025/img/perfil.jpg"
  },
  {
    "revision": "43b8081d408cea9bc8e27d99fd8636ae",
    "url": "/static/v2025/img/perfil.png"
  },
  {
    "revision": "6dc51af6e7a5ac30728639f3cdf62804",
    "url": "/static/v2025/img/search-gray.png"
  },
  {
    "revision": "2e90e4927047c60bf57d947fd87a824b",
    "url": "/static/v2025/img/search.png"
  },
  {
    "revision": "dbb46e053254b0e6a8fc2488275dd6be",
    "url": "/static/v2025/img/search_box_icon36.png"
  },
  {
    "revision": "dbb46e053254b0e6a8fc2488275dd6be",
    "url": "/static/v2025/img/search_box_icon36_delete.png"
  },
  {
    "revision": "f44e50fa5d4b59582aefd69db029343f",
    "url": "/static/v2025/img/spl_logo.png"
  },
  {
    "revision": "9a0717578fe8e07bbd512ec97725cdc0",
    "url": "/static/v2025/img/user.png"
  },
  {
    "revision": "3b26035977e1e888ac2473102fda969f",
    "url": "/static/v2025/index.html"
  },
  {
    "revision": "9e4b286d0ba5598b22e0",
    "url": "/static/v2025/js/app.78d763d1.js"
  },
  {
    "revision": "f739c91e09a7934ac329",
    "url": "/static/v2025/js/chunk-vendors.4d2da48d.js"
  },
  {
    "revision": "a57940c7ace87ec7636c8b98aef7286a",
    "url": "/static/v2025/js/dashboard_custom.js"
  },
  {
    "revision": "48fc550b1b425580ecd2b900f3113ef7",
    "url": "/static/v2025/manifest.json"
  },
  {
    "revision": "3d798458ee267f228251ca2b111181ba",
    "url": "/static/v2025/robots.txt"
  },
  {
    "revision": "06e5b3a635d209f92cd3c794343ed063",
    "url": "/static/v2025/service-worker.js"
  }
]);