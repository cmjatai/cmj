self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d44ac6d2a43c55274f04d4c050ed0692",
    "url": "/static/v2018/brasao/brasao_1024.png"
  },
  {
    "revision": "8f99e5ea64db3fcda01b117954e4af6f",
    "url": "/static/v2018/brasao/brasao_128.png"
  },
  {
    "revision": "6c307cb29fb97f80facd4199fb46d45f",
    "url": "/static/v2018/brasao/brasao_256.png"
  },
  {
    "revision": "2faeef56500a910abf40dd2d98ef9a99",
    "url": "/static/v2018/brasao/brasao_32.png"
  },
  {
    "revision": "7f74a84703400cee7e6807673fd939f8",
    "url": "/static/v2018/brasao/brasao_512.png"
  },
  {
    "revision": "f7b796ce23a9c65a82e199e56efded11",
    "url": "/static/v2018/brasao/brasao_64.png"
  },
  {
    "revision": "af0481c7b1c5abcdd249eccd2092870c",
    "url": "/static/v2018/brasao/escola_1024.png"
  },
  {
    "revision": "0949384907637da381a1",
    "url": "/static/v2018/css/app.ec911cdf.css"
  },
  {
    "revision": "7c9d7e008af0633dedd5",
    "url": "/static/v2018/css/chunk-185bce9d.e32376be.css"
  },
  {
    "revision": "014cbda23861eff59977",
    "url": "/static/v2018/css/chunk-2f6a5bb1.dcab6d0b.css"
  },
  {
    "revision": "79fcaba059a092e3e079",
    "url": "/static/v2018/css/chunk-311ba604.dd929089.css"
  },
  {
    "revision": "28a63b0bfa0072646b13",
    "url": "/static/v2018/css/chunk-37ee3f66.1fe24a2a.css"
  },
  {
    "revision": "cf5dddbc39b461c4db83",
    "url": "/static/v2018/css/chunk-410fae8e.7c557d58.css"
  },
  {
    "revision": "808cfd2d4738ecc72802",
    "url": "/static/v2018/css/chunk-4689f63f.c12863ec.css"
  },
  {
    "revision": "c91830b7f859dda1a110",
    "url": "/static/v2018/css/chunk-64539c42.9cf4e330.css"
  },
  {
    "revision": "b54927ba1899f7620c34",
    "url": "/static/v2018/css/chunk-651183ca.41ddb03a.css"
  },
  {
    "revision": "c681a9fc98ebdd6eb132",
    "url": "/static/v2018/css/chunk-97546066.1a87932c.css"
  },
  {
    "revision": "ce33379516328dd73124",
    "url": "/static/v2018/css/chunk-a62076c0.8a427c26.css"
  },
  {
    "revision": "36635b791293ad0a0741",
    "url": "/static/v2018/css/chunk-ad6ab1be.043a2397.css"
  },
  {
    "revision": "4f2e5d8e0ff5df9ffa0a",
    "url": "/static/v2018/css/chunk-b4547056.1001ad4e.css"
  },
  {
    "revision": "443b5b672216f51c5eea",
    "url": "/static/v2018/css/chunk-d67dac4a.f0b92bd8.css"
  },
  {
    "revision": "ed839ad41a88bf764d3f",
    "url": "/static/v2018/css/chunk-vendors.3ff36de3.css"
  },
  {
    "revision": "9b21ae7aab19abb268b8",
    "url": "/static/v2018/css/compilacao.e398c3b5.css"
  },
  {
    "revision": "6cec4d91f3d1ba44ee26",
    "url": "/static/v2018/css/construct.94274d91.css"
  },
  {
    "revision": "1ab2466858c5b9c773cc",
    "url": "/static/v2018/css/loa.89987e20.css"
  },
  {
    "revision": "0cc039b81a622dd87ea1",
    "url": "/static/v2018/css/painel.fd83c40d.css"
  },
  {
    "revision": "1a575a4138e5f366474f0e7c5bd614a5",
    "url": "/static/v2018/fonts/fa-brands-400.1a575a41.woff"
  },
  {
    "revision": "513aa607d398efaccc559916c3431403",
    "url": "/static/v2018/fonts/fa-brands-400.513aa607.ttf"
  },
  {
    "revision": "592643a83b8541edc52063d84c468700",
    "url": "/static/v2018/fonts/fa-brands-400.592643a8.eot"
  },
  {
    "revision": "ed311c7a0ade9a75bb3ebf5a7670f31d",
    "url": "/static/v2018/fonts/fa-brands-400.ed311c7a.woff2"
  },
  {
    "revision": "766913e6c0088ab8c9f73e18b4127bc4",
    "url": "/static/v2018/fonts/fa-regular-400.766913e6.ttf"
  },
  {
    "revision": "b0e2db3b634d1bc3928e127458d993d8",
    "url": "/static/v2018/fonts/fa-regular-400.b0e2db3b.eot"
  },
  {
    "revision": "b91d376b8d7646d671cd820950d5f7f1",
    "url": "/static/v2018/fonts/fa-regular-400.b91d376b.woff2"
  },
  {
    "revision": "d1d7e3b4c219fde0f7376c6facfd7149",
    "url": "/static/v2018/fonts/fa-regular-400.d1d7e3b4.woff"
  },
  {
    "revision": "0c6bfc668a72935760178f91327aed3a",
    "url": "/static/v2018/fonts/fa-solid-900.0c6bfc66.eot"
  },
  {
    "revision": "b9625119ce4300f0ef890a8f3234c773",
    "url": "/static/v2018/fonts/fa-solid-900.b9625119.ttf"
  },
  {
    "revision": "d745348d289b149026921f197929a893",
    "url": "/static/v2018/fonts/fa-solid-900.d745348d.woff"
  },
  {
    "revision": "d824df7eb2e268626a2dd9a6a741ac4e",
    "url": "/static/v2018/fonts/fa-solid-900.d824df7e.woff2"
  },
  {
    "revision": "7dff63695e03670336c6802fba347192",
    "url": "/static/v2018/img/arrow.png"
  },
  {
    "revision": "0e297f93ffa296cb2bf2782aa94e3268",
    "url": "/static/v2018/img/authenticated.png"
  },
  {
    "revision": "f0ce5b4a7afbc34f6a5b5451a18240a1",
    "url": "/static/v2018/img/avatar.png"
  },
  {
    "revision": "0fedfc17af66cfcd0beaab4a2beec61d",
    "url": "/static/v2018/img/beta.png"
  },
  {
    "revision": "4c35c324fbeb89c16b575c7381f70d6a",
    "url": "/static/v2018/img/bg.png"
  },
  {
    "revision": "39bca038c6e5e11e4f7c1e4ee3389c57",
    "url": "/static/v2018/img/bg_cmj_topo_menu_box_left.png"
  },
  {
    "revision": "e107ac1f05c9ef2c6c629807be229781",
    "url": "/static/v2018/img/bg_cmj_topo_menu_box_right.png"
  },
  {
    "revision": "849c15ec220a24e99aa8506601f41ba9",
    "url": "/static/v2018/img/brasao_transp.gif"
  },
  {
    "revision": "bb1e0825d5223704d2c295f4e1d86b91",
    "url": "/static/v2018/img/down_arrow_select.jpg"
  },
  {
    "revision": "587404969e0999831266a637b48aea4c",
    "url": "/static/v2018/img/etiqueta.png"
  },
  {
    "revision": "1d5619cd804367cefe6da2d79289218a",
    "url": "/static/v2018/img/fa-brands-400.1d5619cd.svg"
  },
  {
    "revision": "c5d109be8edd3de0f60eb472bd9ef691",
    "url": "/static/v2018/img/fa-regular-400.c5d109be.svg"
  },
  {
    "revision": "37bc7099f6f1ba80236164f22e905837",
    "url": "/static/v2018/img/fa-solid-900.37bc7099.svg"
  },
  {
    "revision": "93ba768be99c67b9030dfa2ed3fff325",
    "url": "/static/v2018/img/file.png"
  },
  {
    "revision": "1eb0982bb8b20b77fafda393ae98e76b",
    "url": "/static/v2018/img/foto_aerea_camara_paisagem.jpg"
  },
  {
    "revision": "6fe0dd25f631b39eb6c052e6e43f8177",
    "url": "/static/v2018/img/foto_aerea_camara_retrato.jpg"
  },
  {
    "revision": "cfce175ac693569944dcba9e6c556dcf",
    "url": "/static/v2018/img/foto_chao_camara_paisagem.jpg"
  },
  {
    "revision": "ffe462fdcbc1b3fe6c152bbe9f0b3512",
    "url": "/static/v2018/img/foto_chao_camara_retrato.jpg"
  },
  {
    "revision": "64400f9f98b710c7fd5fd5fe737fa5da",
    "url": "/static/v2018/img/hand-note.png"
  },
  {
    "revision": "02a478243475dc9ba11c7f0915cfeb4b",
    "url": "/static/v2018/img/icon_comissoes.png"
  },
  {
    "revision": "40757133ae49b1a803785cd3b4d291d2",
    "url": "/static/v2018/img/icon_delete_white.png"
  },
  {
    "revision": "717405792fc232b5e210975822cac408",
    "url": "/static/v2018/img/icon_diario_oficial.png"
  },
  {
    "revision": "dbd3da2407bbb56f28b74d0ac573786d",
    "url": "/static/v2018/img/icon_facebook64x64.png"
  },
  {
    "revision": "761d394d64ef531b8abf8a9399ce46ff",
    "url": "/static/v2018/img/icon_favo.761d394d.svg"
  },
  {
    "revision": "c55a1bc2d99244a4c08aa448f361977b",
    "url": "/static/v2018/img/icon_instagram64x64.png"
  },
  {
    "revision": "db910d5dc2b1d30e05766228256eb03d",
    "url": "/static/v2018/img/icon_licitacao.png"
  },
  {
    "revision": "69067c48fb437e151a2f90d2290a70ee",
    "url": "/static/v2018/img/icon_materia_legislativa.png"
  },
  {
    "revision": "d9d48b974febd617d01b336974c30602",
    "url": "/static/v2018/img/icon_mesa_diretora.png"
  },
  {
    "revision": "52266702cd5f7dbdfa8024e799064a52",
    "url": "/static/v2018/img/icon_normas_juridicas.png"
  },
  {
    "revision": "d0c2cc179ab932fb24ea6258f61e6157",
    "url": "/static/v2018/img/icon_normas_juridicas_destaque.png"
  },
  {
    "revision": "aa171389861a663655fd834079f0d039",
    "url": "/static/v2018/img/icon_parlamentares.png"
  },
  {
    "revision": "0558a63d676cc435f2695119e12fdf5f",
    "url": "/static/v2018/img/icon_pautas.png"
  },
  {
    "revision": "f182e226a4ff6fe9408b616b02357cf0",
    "url": "/static/v2018/img/icon_plenarias.png"
  },
  {
    "revision": "02f6e0c106f20a7c6e21a7b523207f47",
    "url": "/static/v2018/img/icon_relatorios.png"
  },
  {
    "revision": "80baf13f86d26f847f3d1b7c7824d4ac",
    "url": "/static/v2018/img/icon_save_white.png"
  },
  {
    "revision": "c79840b15ffb49df44967f48807086b3",
    "url": "/static/v2018/img/icon_telegram64x64.png"
  },
  {
    "revision": "1d5eeaaa12bce45bbff08db8649e8236",
    "url": "/static/v2018/img/icon_transparencia.png"
  },
  {
    "revision": "ef54a640a5c60454a2e7453400bb474f",
    "url": "/static/v2018/img/icon_transparencia_prata.png"
  },
  {
    "revision": "2913dd0f6f0cb6715bccef36b0a1e834",
    "url": "/static/v2018/img/icon_twitter64x64.png"
  },
  {
    "revision": "aeb805abec46d148aad293ef9abffb79",
    "url": "/static/v2018/img/icon_whatsapp64x64.png"
  },
  {
    "revision": "014534399a6fb8befff55baa41e88f40",
    "url": "/static/v2018/img/icon_x_twitter.png"
  },
  {
    "revision": "f8e6bc697c257aa4fb5240c7dcbc97c4",
    "url": "/static/v2018/img/icon_x_twitter.svg"
  },
  {
    "revision": "c2e9627ea8ba42292971f91003af2490",
    "url": "/static/v2018/img/lexml.gif"
  },
  {
    "revision": "91a31efd0faa6d218e52775620e5280e",
    "url": "/static/v2018/img/logo.png"
  },
  {
    "revision": "8f99e5ea64db3fcda01b117954e4af6f",
    "url": "/static/v2018/img/logo_128.png"
  },
  {
    "revision": "317993f5074301653849e01d7650b1b3",
    "url": "/static/v2018/img/logo_cc.png"
  },
  {
    "revision": "06a3dea855d83cb8194e22ab2eabe198",
    "url": "/static/v2018/img/logo_cmj_redesocial.jpg"
  },
  {
    "revision": "59f2f9287bac78d247507ee5c5053dea",
    "url": "/static/v2018/img/logo_interlegis.png"
  },
  {
    "revision": "09e89b66eeb6647dece0197619aec778",
    "url": "/static/v2018/img/logo_portaldocidadao.png"
  },
  {
    "revision": "a1a5cb8ccda80ba8d2e53de044a749a0",
    "url": "/static/v2018/img/logo_sic.png"
  },
  {
    "revision": "8fbc3fa26d7f696fed113c2e72419a02",
    "url": "/static/v2018/img/manual.png"
  },
  {
    "revision": "1f22f15a76c2fd509eadcecc9e9c2b02",
    "url": "/static/v2018/img/pdf_cabec.jpg"
  },
  {
    "revision": "e86d4f3790dcba9d471b7d6ece42e48c",
    "url": "/static/v2018/img/pdf_cabec_margem.jpg"
  },
  {
    "revision": "c0e894ed8b441b6739133c2a7601150d",
    "url": "/static/v2018/img/pdf_rodape.jpg"
  },
  {
    "revision": "64679dab3b056be7ac0c73409f963fcb",
    "url": "/static/v2018/img/pdf_rodape_margem.jpg"
  },
  {
    "revision": "fb71e48b2330408afac41e0bcfbbd4c0",
    "url": "/static/v2018/img/pdflogo.png"
  },
  {
    "revision": "394e657c181354ac1b5c43ce799909a6",
    "url": "/static/v2018/img/perfil.1.jpg"
  },
  {
    "revision": "394e657c181354ac1b5c43ce799909a6",
    "url": "/static/v2018/img/perfil.jpg"
  },
  {
    "revision": "43b8081d408cea9bc8e27d99fd8636ae",
    "url": "/static/v2018/img/perfil.png"
  },
  {
    "revision": "6dc51af6e7a5ac30728639f3cdf62804",
    "url": "/static/v2018/img/search-gray.png"
  },
  {
    "revision": "2e90e4927047c60bf57d947fd87a824b",
    "url": "/static/v2018/img/search.png"
  },
  {
    "revision": "dbb46e053254b0e6a8fc2488275dd6be",
    "url": "/static/v2018/img/search_box_icon36.png"
  },
  {
    "revision": "dbb46e053254b0e6a8fc2488275dd6be",
    "url": "/static/v2018/img/search_box_icon36_delete.png"
  },
  {
    "revision": "f44e50fa5d4b59582aefd69db029343f",
    "url": "/static/v2018/img/spl_logo.png"
  },
  {
    "revision": "9a0717578fe8e07bbd512ec97725cdc0",
    "url": "/static/v2018/img/user.png"
  },
  {
    "revision": "62740a838e33230d2aaf66edca2793dd",
    "url": "/static/v2018/index.html"
  },
  {
    "revision": "0949384907637da381a1",
    "url": "/static/v2018/js/app.1d124d8a.js"
  },
  {
    "revision": "7e4cb636ecc3b20d46d9",
    "url": "/static/v2018/js/chunk-0ad7d0ab.4fb33488.js"
  },
  {
    "revision": "7c9d7e008af0633dedd5",
    "url": "/static/v2018/js/chunk-185bce9d.8723b032.js"
  },
  {
    "revision": "1b516785134797e691ae",
    "url": "/static/v2018/js/chunk-2d0cb66a.c52b82ba.js"
  },
  {
    "revision": "7417f46a29da53a327e2",
    "url": "/static/v2018/js/chunk-2d0e5f08.619efbf6.js"
  },
  {
    "revision": "b25aa440942c4d6f5c1c",
    "url": "/static/v2018/js/chunk-2d216bf1.9440d89d.js"
  },
  {
    "revision": "6264703409136db57724",
    "url": "/static/v2018/js/chunk-2d21a0bf.a04420a8.js"
  },
  {
    "revision": "014cbda23861eff59977",
    "url": "/static/v2018/js/chunk-2f6a5bb1.b064a9cc.js"
  },
  {
    "revision": "79fcaba059a092e3e079",
    "url": "/static/v2018/js/chunk-311ba604.caf9c1ab.js"
  },
  {
    "revision": "28a63b0bfa0072646b13",
    "url": "/static/v2018/js/chunk-37ee3f66.b6f000d5.js"
  },
  {
    "revision": "cf5dddbc39b461c4db83",
    "url": "/static/v2018/js/chunk-410fae8e.3231a7d8.js"
  },
  {
    "revision": "808cfd2d4738ecc72802",
    "url": "/static/v2018/js/chunk-4689f63f.307eb63a.js"
  },
  {
    "revision": "c91830b7f859dda1a110",
    "url": "/static/v2018/js/chunk-64539c42.a2b3414a.js"
  },
  {
    "revision": "b54927ba1899f7620c34",
    "url": "/static/v2018/js/chunk-651183ca.32fd4603.js"
  },
  {
    "revision": "4420b7a0873e344cf227",
    "url": "/static/v2018/js/chunk-77a063de.f7aa1e02.js"
  },
  {
    "revision": "c681a9fc98ebdd6eb132",
    "url": "/static/v2018/js/chunk-97546066.83c3e531.js"
  },
  {
    "revision": "ce33379516328dd73124",
    "url": "/static/v2018/js/chunk-a62076c0.90dbf9ea.js"
  },
  {
    "revision": "36635b791293ad0a0741",
    "url": "/static/v2018/js/chunk-ad6ab1be.9c52b0d9.js"
  },
  {
    "revision": "4f2e5d8e0ff5df9ffa0a",
    "url": "/static/v2018/js/chunk-b4547056.033943c5.js"
  },
  {
    "revision": "443b5b672216f51c5eea",
    "url": "/static/v2018/js/chunk-d67dac4a.76db9bb4.js"
  },
  {
    "revision": "ed839ad41a88bf764d3f",
    "url": "/static/v2018/js/chunk-vendors.d90d1099.js"
  },
  {
    "revision": "9b21ae7aab19abb268b8",
    "url": "/static/v2018/js/compilacao.a5b71c6a.js"
  },
  {
    "revision": "6cec4d91f3d1ba44ee26",
    "url": "/static/v2018/js/construct.d1e5e3a3.js"
  },
  {
    "revision": "a57940c7ace87ec7636c8b98aef7286a",
    "url": "/static/v2018/js/dashboard_custom.js"
  },
  {
    "revision": "1ab2466858c5b9c773cc",
    "url": "/static/v2018/js/loa.42ccf815.js"
  },
  {
    "revision": "0cc039b81a622dd87ea1",
    "url": "/static/v2018/js/painel.8620f5ea.js"
  },
  {
    "revision": "c18a991f9ef0b423adb8b1b132afea6c",
    "url": "/static/v2018/js/skins/content/dark/content.css"
  },
  {
    "revision": "38b9cd18bbec1e79964f94f79df8d322",
    "url": "/static/v2018/js/skins/content/dark/content.js"
  },
  {
    "revision": "8be098c8a09616b6f37f8ed7c963ebca",
    "url": "/static/v2018/js/skins/content/dark/content.min.css"
  },
  {
    "revision": "fdd392b36001c3e0f925e00869fab674",
    "url": "/static/v2018/js/skins/content/default/content.css"
  },
  {
    "revision": "f014cdd3dc76c820424ea0c13706b527",
    "url": "/static/v2018/js/skins/content/default/content.js"
  },
  {
    "revision": "e7448307845064b6e567dabdf0edd81a",
    "url": "/static/v2018/js/skins/content/default/content.min.css"
  },
  {
    "revision": "d6e36fda2726c056c0782b7f0e0d3a33",
    "url": "/static/v2018/js/skins/content/document/content.css"
  },
  {
    "revision": "e133bc2114fa6bd3fb9e6404d5858e40",
    "url": "/static/v2018/js/skins/content/document/content.js"
  },
  {
    "revision": "6cb27dc9ba941235eb2b074c9cbf7126",
    "url": "/static/v2018/js/skins/content/document/content.min.css"
  },
  {
    "revision": "4d9f0e703d7e35ede12e5cc6916ff75b",
    "url": "/static/v2018/js/skins/content/tinymce-5-dark/content.css"
  },
  {
    "revision": "445fd0a046091300c16b598738f48267",
    "url": "/static/v2018/js/skins/content/tinymce-5-dark/content.js"
  },
  {
    "revision": "4e7d595a3352a317ac5457e1544dd018",
    "url": "/static/v2018/js/skins/content/tinymce-5-dark/content.min.css"
  },
  {
    "revision": "fdd392b36001c3e0f925e00869fab674",
    "url": "/static/v2018/js/skins/content/tinymce-5/content.css"
  },
  {
    "revision": "97d1c5e4a709a49fd6f89552fc2e5f87",
    "url": "/static/v2018/js/skins/content/tinymce-5/content.js"
  },
  {
    "revision": "e7448307845064b6e567dabdf0edd81a",
    "url": "/static/v2018/js/skins/content/tinymce-5/content.min.css"
  },
  {
    "revision": "54891f08e9425ba6cfc8285c320f4394",
    "url": "/static/v2018/js/skins/content/writer/content.css"
  },
  {
    "revision": "f11cb3b267cb6d8ede6190a1b736e02a",
    "url": "/static/v2018/js/skins/content/writer/content.js"
  },
  {
    "revision": "5647767d1db4e7cbfe47ab7510c8aeea",
    "url": "/static/v2018/js/skins/content/writer/content.min.css"
  },
  {
    "revision": "a81f21dded3a28cd6a69e058482e9325",
    "url": "/static/v2018/js/skins/ui/oxide-dark/content.css"
  },
  {
    "revision": "b27b20c2f358404b2138fb51bd227990",
    "url": "/static/v2018/js/skins/ui/oxide-dark/content.inline.css"
  },
  {
    "revision": "cb77d29b0f7f21b50e80c842ba8612df",
    "url": "/static/v2018/js/skins/ui/oxide-dark/content.inline.js"
  },
  {
    "revision": "a6c412072a15b50ad031a077d877e678",
    "url": "/static/v2018/js/skins/ui/oxide-dark/content.inline.min.css"
  },
  {
    "revision": "c5f12f08e0df261443c0c9b3fe4f790f",
    "url": "/static/v2018/js/skins/ui/oxide-dark/content.js"
  },
  {
    "revision": "aa57b3161b164cd73df4db5205e08f4a",
    "url": "/static/v2018/js/skins/ui/oxide-dark/content.min.css"
  },
  {
    "revision": "b02cb5429aa20ec4e46aae8b262786f9",
    "url": "/static/v2018/js/skins/ui/oxide-dark/skin.css"
  },
  {
    "revision": "c6955fab969ecdb4f259ef05ddc12b94",
    "url": "/static/v2018/js/skins/ui/oxide-dark/skin.js"
  },
  {
    "revision": "cde5978275cd657e1c3142fcc0834a62",
    "url": "/static/v2018/js/skins/ui/oxide-dark/skin.min.css"
  },
  {
    "revision": "31792aa3530bea8433b3b50c8c38529f",
    "url": "/static/v2018/js/skins/ui/oxide-dark/skin.shadowdom.css"
  },
  {
    "revision": "e96d3c218f2b79f82e2c87b6f3f818bb",
    "url": "/static/v2018/js/skins/ui/oxide-dark/skin.shadowdom.js"
  },
  {
    "revision": "1448b0502cbc52a71d7b2a5eaa9f3847",
    "url": "/static/v2018/js/skins/ui/oxide-dark/skin.shadowdom.min.css"
  },
  {
    "revision": "9d07f566e722dfe95f538778f481c868",
    "url": "/static/v2018/js/skins/ui/oxide/content.css"
  },
  {
    "revision": "b27b20c2f358404b2138fb51bd227990",
    "url": "/static/v2018/js/skins/ui/oxide/content.inline.css"
  },
  {
    "revision": "de8c1cf867891f83538bd89d07d96358",
    "url": "/static/v2018/js/skins/ui/oxide/content.inline.js"
  },
  {
    "revision": "a6c412072a15b50ad031a077d877e678",
    "url": "/static/v2018/js/skins/ui/oxide/content.inline.min.css"
  },
  {
    "revision": "989f816397edd4b304da863f48fda91c",
    "url": "/static/v2018/js/skins/ui/oxide/content.js"
  },
  {
    "revision": "821a32db5e28e6b996697e2e07626349",
    "url": "/static/v2018/js/skins/ui/oxide/content.min.css"
  },
  {
    "revision": "ad61522bcbda78cfaf7c498ec8262940",
    "url": "/static/v2018/js/skins/ui/oxide/skin.css"
  },
  {
    "revision": "a76b50e3459064ee98d212963136bd92",
    "url": "/static/v2018/js/skins/ui/oxide/skin.js"
  },
  {
    "revision": "4c1369cf6083f903e3216a5124f15290",
    "url": "/static/v2018/js/skins/ui/oxide/skin.min.css"
  },
  {
    "revision": "31792aa3530bea8433b3b50c8c38529f",
    "url": "/static/v2018/js/skins/ui/oxide/skin.shadowdom.css"
  },
  {
    "revision": "fb3cc71941cdc2e83de399ee39abe36d",
    "url": "/static/v2018/js/skins/ui/oxide/skin.shadowdom.js"
  },
  {
    "revision": "1448b0502cbc52a71d7b2a5eaa9f3847",
    "url": "/static/v2018/js/skins/ui/oxide/skin.shadowdom.min.css"
  },
  {
    "revision": "88176b46d5b3cef7ed0dce3f9b2e7978",
    "url": "/static/v2018/js/skins/ui/tinymce-5-dark/content.css"
  },
  {
    "revision": "b27b20c2f358404b2138fb51bd227990",
    "url": "/static/v2018/js/skins/ui/tinymce-5-dark/content.inline.css"
  },
  {
    "revision": "f0eb7e184865f7bc0720ccdc0e172729",
    "url": "/static/v2018/js/skins/ui/tinymce-5-dark/content.inline.js"
  },
  {
    "revision": "a6c412072a15b50ad031a077d877e678",
    "url": "/static/v2018/js/skins/ui/tinymce-5-dark/content.inline.min.css"
  },
  {
    "revision": "ed1e7b7415d372ec3d6e01781b67e5fd",
    "url": "/static/v2018/js/skins/ui/tinymce-5-dark/content.js"
  },
  {
    "revision": "99f63ebfa6fa0e68c3a37d941d385151",
    "url": "/static/v2018/js/skins/ui/tinymce-5-dark/content.min.css"
  },
  {
    "revision": "d0da2845486c4b75e1063cfbceb87e96",
    "url": "/static/v2018/js/skins/ui/tinymce-5-dark/skin.css"
  },
  {
    "revision": "9999bcdaef9d2d6647454dc92ce9810d",
    "url": "/static/v2018/js/skins/ui/tinymce-5-dark/skin.js"
  },
  {
    "revision": "259ccbe515d9596d0a839b67d59e1e66",
    "url": "/static/v2018/js/skins/ui/tinymce-5-dark/skin.min.css"
  },
  {
    "revision": "31792aa3530bea8433b3b50c8c38529f",
    "url": "/static/v2018/js/skins/ui/tinymce-5-dark/skin.shadowdom.css"
  },
  {
    "revision": "eb127cec1c96aebc630b4f9f5efcbf7e",
    "url": "/static/v2018/js/skins/ui/tinymce-5-dark/skin.shadowdom.js"
  },
  {
    "revision": "1448b0502cbc52a71d7b2a5eaa9f3847",
    "url": "/static/v2018/js/skins/ui/tinymce-5-dark/skin.shadowdom.min.css"
  },
  {
    "revision": "9d07f566e722dfe95f538778f481c868",
    "url": "/static/v2018/js/skins/ui/tinymce-5/content.css"
  },
  {
    "revision": "b27b20c2f358404b2138fb51bd227990",
    "url": "/static/v2018/js/skins/ui/tinymce-5/content.inline.css"
  },
  {
    "revision": "d3e81b6cf4bd844128775cc04035dcef",
    "url": "/static/v2018/js/skins/ui/tinymce-5/content.inline.js"
  },
  {
    "revision": "a6c412072a15b50ad031a077d877e678",
    "url": "/static/v2018/js/skins/ui/tinymce-5/content.inline.min.css"
  },
  {
    "revision": "c6f4441c116126ef1f299ccfdcbc733d",
    "url": "/static/v2018/js/skins/ui/tinymce-5/content.js"
  },
  {
    "revision": "821a32db5e28e6b996697e2e07626349",
    "url": "/static/v2018/js/skins/ui/tinymce-5/content.min.css"
  },
  {
    "revision": "349974f70449a482750f5181a4fa7455",
    "url": "/static/v2018/js/skins/ui/tinymce-5/skin.css"
  },
  {
    "revision": "2da33d74c83d0c128ea2a2c55a8d80b6",
    "url": "/static/v2018/js/skins/ui/tinymce-5/skin.js"
  },
  {
    "revision": "1e616f9e05fac9163d97a9b296dc84fd",
    "url": "/static/v2018/js/skins/ui/tinymce-5/skin.min.css"
  },
  {
    "revision": "31792aa3530bea8433b3b50c8c38529f",
    "url": "/static/v2018/js/skins/ui/tinymce-5/skin.shadowdom.css"
  },
  {
    "revision": "7d0e89599f3017f7e3941b47f71afee3",
    "url": "/static/v2018/js/skins/ui/tinymce-5/skin.shadowdom.js"
  },
  {
    "revision": "1448b0502cbc52a71d7b2a5eaa9f3847",
    "url": "/static/v2018/js/skins/ui/tinymce-5/skin.shadowdom.min.css"
  },
  {
    "revision": "5b5416a209f2f0f2110b433f34a9eb8d",
    "url": "/static/v2018/js/sync.worker.606b0748.worker.js"
  },
  {
    "revision": "9e027c4c9378b0b8c885ab02bcc57dd1",
    "url": "/static/v2018/js/timer.worker.d94083b1.worker.js"
  },
  {
    "revision": "2535603c64d9c8e198c52232fca2e6b9",
    "url": "/static/v2018/manifest.json"
  },
  {
    "revision": "3d798458ee267f228251ca2b111181ba",
    "url": "/static/v2018/robots.txt"
  },
  {
    "revision": "06e5b3a635d209f92cd3c794343ed063",
    "url": "/static/v2018/service-worker.js"
  }
]);