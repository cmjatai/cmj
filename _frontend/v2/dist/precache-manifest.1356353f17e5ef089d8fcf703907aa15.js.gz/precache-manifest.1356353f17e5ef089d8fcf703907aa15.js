self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d44ac6d2a43c55274f04d4c050ed0692",
    "url": "/static/brasao/brasao_1024.png"
  },
  {
    "revision": "8f99e5ea64db3fcda01b117954e4af6f",
    "url": "/static/brasao/brasao_128.png"
  },
  {
    "revision": "6c307cb29fb97f80facd4199fb46d45f",
    "url": "/static/brasao/brasao_256.png"
  },
  {
    "revision": "7f74a84703400cee7e6807673fd939f8",
    "url": "/static/brasao/brasao_512.png"
  },
  {
    "revision": "11d1c4c54cfb340896b6",
    "url": "/static/css/app.b6cf9e14.css"
  },
  {
    "revision": "c005862d7a730e681652",
    "url": "/static/css/chunk-44ab9ccc.6acea37f.css"
  },
  {
    "revision": "c9934b4b68b0f843ed43",
    "url": "/static/css/chunk-5cedb00e.c515a2da.css"
  },
  {
    "revision": "dfe822e3fa5104e21caa",
    "url": "/static/css/chunk-682be98a.707facdf.css"
  },
  {
    "revision": "9b9d4f9618c2f461647b",
    "url": "/static/css/chunk-vendors.2fe795fd.css"
  },
  {
    "revision": "4c59245cf67e1f6171c47bf1e242b106",
    "url": "/static/img/header_bg_fill.png"
  },
  {
    "revision": "6726782cc799e47157e9442ca0a13745",
    "url": "/static/img/header_bg_linha.png"
  },
  {
    "revision": "e12f38146f24c97d1133b2d2b502c13c",
    "url": "/static/img/icon.e12f3814.svg"
  },
  {
    "revision": "9516930cfe890ecff6fb60409fc4e945",
    "url": "/static/img/icon_atividade_legislativa.9516930c.svg"
  },
  {
    "revision": "c545c4a743ff7e182e24d84f2424e5fa",
    "url": "/static/img/icon_doc_adm.c545c4a7.svg"
  },
  {
    "revision": "d507cda3770c0c4663c89aec2984e0db",
    "url": "/static/img/icon_plenarias.d507cda3.svg"
  },
  {
    "revision": "e736437c61edc388dcab3a33dd247e2c",
    "url": "/static/img/icon_prestacao_contas.e736437c.svg"
  },
  {
    "revision": "296d5d8e05785fd7d04439e18e9ff91d",
    "url": "/static/img/pdf_cabec.jpg"
  },
  {
    "revision": "c0e894ed8b441b6739133c2a7601150d",
    "url": "/static/img/pdf_rodape.jpg"
  },
  {
    "revision": "def5f60c89118a680de38973a5e4c871",
    "url": "/static/index.html"
  },
  {
    "revision": "11d1c4c54cfb340896b6",
    "url": "/static/js/app.7b750326.js"
  },
  {
    "revision": "7562403a1b4bef588d85",
    "url": "/static/js/chunk-2d0d8018.71303963.js"
  },
  {
    "revision": "15268fda140db14b9da9",
    "url": "/static/js/chunk-2d225d57.4ac17fe7.js"
  },
  {
    "revision": "c005862d7a730e681652",
    "url": "/static/js/chunk-44ab9ccc.180af1da.js"
  },
  {
    "revision": "c9934b4b68b0f843ed43",
    "url": "/static/js/chunk-5cedb00e.aac3dc82.js"
  },
  {
    "revision": "dfe822e3fa5104e21caa",
    "url": "/static/js/chunk-682be98a.3566d2f0.js"
  },
  {
    "revision": "9b9d4f9618c2f461647b",
    "url": "/static/js/chunk-vendors.99b5d35d.js"
  },
  {
    "revision": "7516fc313b953a9501c3ae0c58933f63",
    "url": "/static/manifest.json"
  },
  {
    "revision": "5db7f7f9589fb1173f80593d7de83f59",
    "url": "/static/robots.txt"
  },
  {
    "revision": "a86f9f2ebe3931d7b46e266c05625689",
    "url": "/static/service-worker.js"
  }
]);