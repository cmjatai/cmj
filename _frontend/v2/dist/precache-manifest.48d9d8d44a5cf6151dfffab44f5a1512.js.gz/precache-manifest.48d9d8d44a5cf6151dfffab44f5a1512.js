self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d44ac6d2a43c55274f04d4c050ed0692",
    "url": "/static/brasao/brasao_1024.png"
  },
  {
    "revision": "8f99e5ea64db3fcda01b117954e4af6f",
    "url": "/static/brasao/brasao_128.png"
  },
  {
    "revision": "6c307cb29fb97f80facd4199fb46d45f",
    "url": "/static/brasao/brasao_256.png"
  },
  {
    "revision": "7f74a84703400cee7e6807673fd939f8",
    "url": "/static/brasao/brasao_512.png"
  },
  {
    "revision": "dbf0a933ea1c5638b171",
    "url": "/static/css/app.f72a4309.css"
  },
  {
    "revision": "a2d084fe7c3dcc67784a",
    "url": "/static/css/chunk-20cd9e74.c515a2da.css"
  },
  {
    "revision": "3cfd821878833170b1fc",
    "url": "/static/css/chunk-f11218b8.707facdf.css"
  },
  {
    "revision": "e347b49ce60bb01d151f",
    "url": "/static/css/chunk-f522cece.6acea37f.css"
  },
  {
    "revision": "7d254dcb82f4fe014c74",
    "url": "/static/css/chunk-vendors.2fe795fd.css"
  },
  {
    "revision": "4c59245cf67e1f6171c47bf1e242b106",
    "url": "/static/img/header_bg_fill.png"
  },
  {
    "revision": "6726782cc799e47157e9442ca0a13745",
    "url": "/static/img/header_bg_linha.png"
  },
  {
    "revision": "e12f38146f24c97d1133b2d2b502c13c",
    "url": "/static/img/icon.e12f3814.svg"
  },
  {
    "revision": "9516930cfe890ecff6fb60409fc4e945",
    "url": "/static/img/icon_atividade_legislativa.9516930c.svg"
  },
  {
    "revision": "c545c4a743ff7e182e24d84f2424e5fa",
    "url": "/static/img/icon_doc_adm.c545c4a7.svg"
  },
  {
    "revision": "d507cda3770c0c4663c89aec2984e0db",
    "url": "/static/img/icon_plenarias.d507cda3.svg"
  },
  {
    "revision": "e736437c61edc388dcab3a33dd247e2c",
    "url": "/static/img/icon_prestacao_contas.e736437c.svg"
  },
  {
    "revision": "abcd22410e1313ec8625a6f21dfd41e9",
    "url": "/static/index.html"
  },
  {
    "revision": "dbf0a933ea1c5638b171",
    "url": "/static/js/app.77f7da34.js"
  },
  {
    "revision": "a2d084fe7c3dcc67784a",
    "url": "/static/js/chunk-20cd9e74.8230ba33.js"
  },
  {
    "revision": "7e2aa29b3b9ea143552f",
    "url": "/static/js/chunk-2d0c4a82.813e7abc.js"
  },
  {
    "revision": "7562403a1b4bef588d85",
    "url": "/static/js/chunk-2d0d8018.71303963.js"
  },
  {
    "revision": "3cfd821878833170b1fc",
    "url": "/static/js/chunk-f11218b8.fe0a371c.js"
  },
  {
    "revision": "e347b49ce60bb01d151f",
    "url": "/static/js/chunk-f522cece.452bb7b1.js"
  },
  {
    "revision": "7d254dcb82f4fe014c74",
    "url": "/static/js/chunk-vendors.bd5fafa4.js"
  },
  {
    "revision": "7516fc313b953a9501c3ae0c58933f63",
    "url": "/static/manifest.json"
  },
  {
    "revision": "5db7f7f9589fb1173f80593d7de83f59",
    "url": "/static/robots.txt"
  },
  {
    "revision": "a86f9f2ebe3931d7b46e266c05625689",
    "url": "/static/service-worker.js"
  }
]);