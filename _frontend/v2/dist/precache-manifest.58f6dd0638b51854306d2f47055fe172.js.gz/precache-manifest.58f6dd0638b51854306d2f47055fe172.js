self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d44ac6d2a43c55274f04d4c050ed0692",
    "url": "/static/brasao/brasao_1024.png"
  },
  {
    "revision": "8f99e5ea64db3fcda01b117954e4af6f",
    "url": "/static/brasao/brasao_128.png"
  },
  {
    "revision": "6c307cb29fb97f80facd4199fb46d45f",
    "url": "/static/brasao/brasao_256.png"
  },
  {
    "revision": "7f74a84703400cee7e6807673fd939f8",
    "url": "/static/brasao/brasao_512.png"
  },
  {
    "revision": "f6890612ed60c894936b",
    "url": "/static/css/app.671574bf.css"
  },
  {
    "revision": "d2d7d838ef709f50246d",
    "url": "/static/css/chunk-vendors.2fe795fd.css"
  },
  {
    "revision": "4c59245cf67e1f6171c47bf1e242b106",
    "url": "/static/img/header_bg_fill.png"
  },
  {
    "revision": "6726782cc799e47157e9442ca0a13745",
    "url": "/static/img/header_bg_linha.png"
  },
  {
    "revision": "e12f38146f24c97d1133b2d2b502c13c",
    "url": "/static/img/icon.e12f3814.svg"
  },
  {
    "revision": "9516930cfe890ecff6fb60409fc4e945",
    "url": "/static/img/icon_atividade_legislativa.9516930c.svg"
  },
  {
    "revision": "c545c4a743ff7e182e24d84f2424e5fa",
    "url": "/static/img/icon_doc_adm.c545c4a7.svg"
  },
  {
    "revision": "d507cda3770c0c4663c89aec2984e0db",
    "url": "/static/img/icon_plenarias.d507cda3.svg"
  },
  {
    "revision": "e736437c61edc388dcab3a33dd247e2c",
    "url": "/static/img/icon_prestacao_contas.e736437c.svg"
  },
  {
    "revision": "3e7b3ece46e37c8e30a2d6153a7c126c",
    "url": "/static/index.html"
  },
  {
    "revision": "f6890612ed60c894936b",
    "url": "/static/js/app.81febc63.js"
  },
  {
    "revision": "589ef26938cc8d653cce",
    "url": "/static/js/chunk-2d22d746.b4c82dc4.js"
  },
  {
    "revision": "d2d7d838ef709f50246d",
    "url": "/static/js/chunk-vendors.9e10c17e.js"
  },
  {
    "revision": "7516fc313b953a9501c3ae0c58933f63",
    "url": "/static/manifest.json"
  },
  {
    "revision": "5db7f7f9589fb1173f80593d7de83f59",
    "url": "/static/robots.txt"
  },
  {
    "revision": "a86f9f2ebe3931d7b46e266c05625689",
    "url": "/static/service-worker.js"
  }
]);