self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d44ac6d2a43c55274f04d4c050ed0692",
    "url": "/static/brasao/brasao_1024.png"
  },
  {
    "revision": "8f99e5ea64db3fcda01b117954e4af6f",
    "url": "/static/brasao/brasao_128.png"
  },
  {
    "revision": "6c307cb29fb97f80facd4199fb46d45f",
    "url": "/static/brasao/brasao_256.png"
  },
  {
    "revision": "2faeef56500a910abf40dd2d98ef9a99",
    "url": "/static/brasao/brasao_32.png"
  },
  {
    "revision": "7f74a84703400cee7e6807673fd939f8",
    "url": "/static/brasao/brasao_512.png"
  },
  {
    "revision": "f7b796ce23a9c65a82e199e56efded11",
    "url": "/static/brasao/brasao_64.png"
  },
  {
    "revision": "af0481c7b1c5abcdd249eccd2092870c",
    "url": "/static/brasao/escola_1024.png"
  },
  {
    "revision": "98e045a51f7f6f3fc1ca",
    "url": "/static/css/app.849411f3.css"
  },
  {
    "revision": "9ed5a2a52ccce1d7b4c2",
    "url": "/static/css/chunk-0ec9d5db.1c736b92.css"
  },
  {
    "revision": "0a430f575895c0a65ac6",
    "url": "/static/css/chunk-35a23a2b.c47654b7.css"
  },
  {
    "revision": "b87a1005b95c47e78323",
    "url": "/static/css/chunk-6f0ff250.707facdf.css"
  },
  {
    "revision": "282aa4016a804cbcec39",
    "url": "/static/css/chunk-74f82fc3.e32376be.css"
  },
  {
    "revision": "980331cca040793dc7e3",
    "url": "/static/css/chunk-763df01a.71109f00.css"
  },
  {
    "revision": "2eb3b82632657e049a42",
    "url": "/static/css/chunk-dfd0331c.91f17d17.css"
  },
  {
    "revision": "3792693ea23ad3ebfc98",
    "url": "/static/css/chunk-e3b66cee.c11a91b4.css"
  },
  {
    "revision": "3ab32d59b508dd6695a5",
    "url": "/static/css/chunk-vendors.b19a7823.css"
  },
  {
    "revision": "9f6864ee7184cefed403",
    "url": "/static/css/compilacao.97eefa6c.css"
  },
  {
    "revision": "8230a0a3c0544cb3bb87",
    "url": "/static/css/construct.3d35e86c.css"
  },
  {
    "revision": "c7b4fcace31ea4c393e4",
    "url": "/static/css/painel.fd83c40d.css"
  },
  {
    "revision": "1a575a4138e5f366474f0e7c5bd614a5",
    "url": "/static/fonts/fa-brands-400.1a575a41.woff"
  },
  {
    "revision": "513aa607d398efaccc559916c3431403",
    "url": "/static/fonts/fa-brands-400.513aa607.ttf"
  },
  {
    "revision": "592643a83b8541edc52063d84c468700",
    "url": "/static/fonts/fa-brands-400.592643a8.eot"
  },
  {
    "revision": "ed311c7a0ade9a75bb3ebf5a7670f31d",
    "url": "/static/fonts/fa-brands-400.ed311c7a.woff2"
  },
  {
    "revision": "766913e6c0088ab8c9f73e18b4127bc4",
    "url": "/static/fonts/fa-regular-400.766913e6.ttf"
  },
  {
    "revision": "b0e2db3b634d1bc3928e127458d993d8",
    "url": "/static/fonts/fa-regular-400.b0e2db3b.eot"
  },
  {
    "revision": "b91d376b8d7646d671cd820950d5f7f1",
    "url": "/static/fonts/fa-regular-400.b91d376b.woff2"
  },
  {
    "revision": "d1d7e3b4c219fde0f7376c6facfd7149",
    "url": "/static/fonts/fa-regular-400.d1d7e3b4.woff"
  },
  {
    "revision": "0c6bfc668a72935760178f91327aed3a",
    "url": "/static/fonts/fa-solid-900.0c6bfc66.eot"
  },
  {
    "revision": "b9625119ce4300f0ef890a8f3234c773",
    "url": "/static/fonts/fa-solid-900.b9625119.ttf"
  },
  {
    "revision": "d745348d289b149026921f197929a893",
    "url": "/static/fonts/fa-solid-900.d745348d.woff"
  },
  {
    "revision": "d824df7eb2e268626a2dd9a6a741ac4e",
    "url": "/static/fonts/fa-solid-900.d824df7e.woff2"
  },
  {
    "revision": "7dff63695e03670336c6802fba347192",
    "url": "/static/img/arrow.png"
  },
  {
    "revision": "0e297f93ffa296cb2bf2782aa94e3268",
    "url": "/static/img/authenticated.png"
  },
  {
    "revision": "f0ce5b4a7afbc34f6a5b5451a18240a1",
    "url": "/static/img/avatar.png"
  },
  {
    "revision": "0fedfc17af66cfcd0beaab4a2beec61d",
    "url": "/static/img/beta.png"
  },
  {
    "revision": "4c35c324fbeb89c16b575c7381f70d6a",
    "url": "/static/img/bg.png"
  },
  {
    "revision": "39bca038c6e5e11e4f7c1e4ee3389c57",
    "url": "/static/img/bg_cmj_topo_menu_box_left.png"
  },
  {
    "revision": "e107ac1f05c9ef2c6c629807be229781",
    "url": "/static/img/bg_cmj_topo_menu_box_right.png"
  },
  {
    "revision": "849c15ec220a24e99aa8506601f41ba9",
    "url": "/static/img/brasao_transp.gif"
  },
  {
    "revision": "bb1e0825d5223704d2c295f4e1d86b91",
    "url": "/static/img/down_arrow_select.jpg"
  },
  {
    "revision": "587404969e0999831266a637b48aea4c",
    "url": "/static/img/etiqueta.png"
  },
  {
    "revision": "1d5619cd804367cefe6da2d79289218a",
    "url": "/static/img/fa-brands-400.1d5619cd.svg"
  },
  {
    "revision": "c5d109be8edd3de0f60eb472bd9ef691",
    "url": "/static/img/fa-regular-400.c5d109be.svg"
  },
  {
    "revision": "37bc7099f6f1ba80236164f22e905837",
    "url": "/static/img/fa-solid-900.37bc7099.svg"
  },
  {
    "revision": "93ba768be99c67b9030dfa2ed3fff325",
    "url": "/static/img/file.png"
  },
  {
    "revision": "64400f9f98b710c7fd5fd5fe737fa5da",
    "url": "/static/img/hand-note.png"
  },
  {
    "revision": "02a478243475dc9ba11c7f0915cfeb4b",
    "url": "/static/img/icon_comissoes.png"
  },
  {
    "revision": "40757133ae49b1a803785cd3b4d291d2",
    "url": "/static/img/icon_delete_white.png"
  },
  {
    "revision": "717405792fc232b5e210975822cac408",
    "url": "/static/img/icon_diario_oficial.png"
  },
  {
    "revision": "dbd3da2407bbb56f28b74d0ac573786d",
    "url": "/static/img/icon_facebook64x64.png"
  },
  {
    "revision": "761d394d64ef531b8abf8a9399ce46ff",
    "url": "/static/img/icon_favo.761d394d.svg"
  },
  {
    "revision": "c55a1bc2d99244a4c08aa448f361977b",
    "url": "/static/img/icon_instagram64x64.png"
  },
  {
    "revision": "db910d5dc2b1d30e05766228256eb03d",
    "url": "/static/img/icon_licitacao.png"
  },
  {
    "revision": "69067c48fb437e151a2f90d2290a70ee",
    "url": "/static/img/icon_materia_legislativa.png"
  },
  {
    "revision": "d9d48b974febd617d01b336974c30602",
    "url": "/static/img/icon_mesa_diretora.png"
  },
  {
    "revision": "52266702cd5f7dbdfa8024e799064a52",
    "url": "/static/img/icon_normas_juridicas.png"
  },
  {
    "revision": "d0c2cc179ab932fb24ea6258f61e6157",
    "url": "/static/img/icon_normas_juridicas_destaque.png"
  },
  {
    "revision": "aa171389861a663655fd834079f0d039",
    "url": "/static/img/icon_parlamentares.png"
  },
  {
    "revision": "0558a63d676cc435f2695119e12fdf5f",
    "url": "/static/img/icon_pautas.png"
  },
  {
    "revision": "f182e226a4ff6fe9408b616b02357cf0",
    "url": "/static/img/icon_plenarias.png"
  },
  {
    "revision": "02f6e0c106f20a7c6e21a7b523207f47",
    "url": "/static/img/icon_relatorios.png"
  },
  {
    "revision": "80baf13f86d26f847f3d1b7c7824d4ac",
    "url": "/static/img/icon_save_white.png"
  },
  {
    "revision": "c79840b15ffb49df44967f48807086b3",
    "url": "/static/img/icon_telegram64x64.png"
  },
  {
    "revision": "1d5eeaaa12bce45bbff08db8649e8236",
    "url": "/static/img/icon_transparencia.png"
  },
  {
    "revision": "2913dd0f6f0cb6715bccef36b0a1e834",
    "url": "/static/img/icon_twitter64x64.png"
  },
  {
    "revision": "aeb805abec46d148aad293ef9abffb79",
    "url": "/static/img/icon_whatsapp64x64.png"
  },
  {
    "revision": "c2e9627ea8ba42292971f91003af2490",
    "url": "/static/img/lexml.gif"
  },
  {
    "revision": "91a31efd0faa6d218e52775620e5280e",
    "url": "/static/img/logo.png"
  },
  {
    "revision": "8f99e5ea64db3fcda01b117954e4af6f",
    "url": "/static/img/logo_128.png"
  },
  {
    "revision": "317993f5074301653849e01d7650b1b3",
    "url": "/static/img/logo_cc.png"
  },
  {
    "revision": "06a3dea855d83cb8194e22ab2eabe198",
    "url": "/static/img/logo_cmj_redesocial.jpg"
  },
  {
    "revision": "59f2f9287bac78d247507ee5c5053dea",
    "url": "/static/img/logo_interlegis.png"
  },
  {
    "revision": "a1a5cb8ccda80ba8d2e53de044a749a0",
    "url": "/static/img/logo_sic.png"
  },
  {
    "revision": "8fbc3fa26d7f696fed113c2e72419a02",
    "url": "/static/img/manual.png"
  },
  {
    "revision": "296d5d8e05785fd7d04439e18e9ff91d",
    "url": "/static/img/pdf_cabec.jpg"
  },
  {
    "revision": "e86d4f3790dcba9d471b7d6ece42e48c",
    "url": "/static/img/pdf_cabec_margem.jpg"
  },
  {
    "revision": "c0e894ed8b441b6739133c2a7601150d",
    "url": "/static/img/pdf_rodape.jpg"
  },
  {
    "revision": "64679dab3b056be7ac0c73409f963fcb",
    "url": "/static/img/pdf_rodape_margem.jpg"
  },
  {
    "revision": "fb71e48b2330408afac41e0bcfbbd4c0",
    "url": "/static/img/pdflogo.png"
  },
  {
    "revision": "394e657c181354ac1b5c43ce799909a6",
    "url": "/static/img/perfil.1.jpg"
  },
  {
    "revision": "394e657c181354ac1b5c43ce799909a6",
    "url": "/static/img/perfil.jpg"
  },
  {
    "revision": "43b8081d408cea9bc8e27d99fd8636ae",
    "url": "/static/img/perfil.png"
  },
  {
    "revision": "6dc51af6e7a5ac30728639f3cdf62804",
    "url": "/static/img/search-gray.png"
  },
  {
    "revision": "2e90e4927047c60bf57d947fd87a824b",
    "url": "/static/img/search.png"
  },
  {
    "revision": "dbb46e053254b0e6a8fc2488275dd6be",
    "url": "/static/img/search_box_icon36.png"
  },
  {
    "revision": "dbb46e053254b0e6a8fc2488275dd6be",
    "url": "/static/img/search_box_icon36_delete.png"
  },
  {
    "revision": "9a0717578fe8e07bbd512ec97725cdc0",
    "url": "/static/img/user.png"
  },
  {
    "revision": "81ab90da8846ce5b729e0c2ad584192c",
    "url": "/static/index.html"
  },
  {
    "revision": "98e045a51f7f6f3fc1ca",
    "url": "/static/js/app.2cfeb356.js"
  },
  {
    "revision": "9ed5a2a52ccce1d7b4c2",
    "url": "/static/js/chunk-0ec9d5db.6e6e980a.js"
  },
  {
    "revision": "49482ccb5ca1dc86b975",
    "url": "/static/js/chunk-2d0cb66a.cea9ab46.js"
  },
  {
    "revision": "0a430f575895c0a65ac6",
    "url": "/static/js/chunk-35a23a2b.7f0e9f2f.js"
  },
  {
    "revision": "5b85fa29575dc29b5470",
    "url": "/static/js/chunk-6c8746c3.64a5b81f.js"
  },
  {
    "revision": "b87a1005b95c47e78323",
    "url": "/static/js/chunk-6f0ff250.c8f80b48.js"
  },
  {
    "revision": "282aa4016a804cbcec39",
    "url": "/static/js/chunk-74f82fc3.2fd7e865.js"
  },
  {
    "revision": "980331cca040793dc7e3",
    "url": "/static/js/chunk-763df01a.33a041d9.js"
  },
  {
    "revision": "7dc7fcaf37e77bcbf793",
    "url": "/static/js/chunk-7a782422.f94be4b8.js"
  },
  {
    "revision": "2eb3b82632657e049a42",
    "url": "/static/js/chunk-dfd0331c.dc32fd31.js"
  },
  {
    "revision": "3792693ea23ad3ebfc98",
    "url": "/static/js/chunk-e3b66cee.1475ae01.js"
  },
  {
    "revision": "3ab32d59b508dd6695a5",
    "url": "/static/js/chunk-vendors.5005b05d.js"
  },
  {
    "revision": "9f6864ee7184cefed403",
    "url": "/static/js/compilacao.1a296406.js"
  },
  {
    "revision": "8230a0a3c0544cb3bb87",
    "url": "/static/js/construct.7aa8bf23.js"
  },
  {
    "revision": "c7b4fcace31ea4c393e4",
    "url": "/static/js/painel.204833ed.js"
  },
  {
    "revision": "c18a991f9ef0b423adb8b1b132afea6c",
    "url": "/static/js/skins/content/dark/content.css"
  },
  {
    "revision": "3ba04d24c1d4ea870209e677833051b3",
    "url": "/static/js/skins/content/dark/content.js"
  },
  {
    "revision": "8be098c8a09616b6f37f8ed7c963ebca",
    "url": "/static/js/skins/content/dark/content.min.css"
  },
  {
    "revision": "fdd392b36001c3e0f925e00869fab674",
    "url": "/static/js/skins/content/default/content.css"
  },
  {
    "revision": "4884931f5479b8fab6b5c239e0cce3ce",
    "url": "/static/js/skins/content/default/content.js"
  },
  {
    "revision": "e7448307845064b6e567dabdf0edd81a",
    "url": "/static/js/skins/content/default/content.min.css"
  },
  {
    "revision": "d6e36fda2726c056c0782b7f0e0d3a33",
    "url": "/static/js/skins/content/document/content.css"
  },
  {
    "revision": "fd56bdc31b11421b75c3619e2ccaab3a",
    "url": "/static/js/skins/content/document/content.js"
  },
  {
    "revision": "6cb27dc9ba941235eb2b074c9cbf7126",
    "url": "/static/js/skins/content/document/content.min.css"
  },
  {
    "revision": "4d9f0e703d7e35ede12e5cc6916ff75b",
    "url": "/static/js/skins/content/tinymce-5-dark/content.css"
  },
  {
    "revision": "9997ea61b2ab94e6ed73693936019e70",
    "url": "/static/js/skins/content/tinymce-5-dark/content.js"
  },
  {
    "revision": "4e7d595a3352a317ac5457e1544dd018",
    "url": "/static/js/skins/content/tinymce-5-dark/content.min.css"
  },
  {
    "revision": "fdd392b36001c3e0f925e00869fab674",
    "url": "/static/js/skins/content/tinymce-5/content.css"
  },
  {
    "revision": "9a7a8a9810ee9a3910d56cfd1d5d8446",
    "url": "/static/js/skins/content/tinymce-5/content.js"
  },
  {
    "revision": "e7448307845064b6e567dabdf0edd81a",
    "url": "/static/js/skins/content/tinymce-5/content.min.css"
  },
  {
    "revision": "54891f08e9425ba6cfc8285c320f4394",
    "url": "/static/js/skins/content/writer/content.css"
  },
  {
    "revision": "76f3e530f7ba6b52e20858c4dbf37765",
    "url": "/static/js/skins/content/writer/content.js"
  },
  {
    "revision": "5647767d1db4e7cbfe47ab7510c8aeea",
    "url": "/static/js/skins/content/writer/content.min.css"
  },
  {
    "revision": "0e07e4d5a73e6a96ad16b956d9054cb9",
    "url": "/static/js/skins/ui/oxide-dark/content.css"
  },
  {
    "revision": "d7cd93d57d013b0cc029f065d4006fda",
    "url": "/static/js/skins/ui/oxide-dark/content.inline.css"
  },
  {
    "revision": "b3f451d17b8779d60fd980041fedae5b",
    "url": "/static/js/skins/ui/oxide-dark/content.inline.js"
  },
  {
    "revision": "0120d4d3c9bb3dbf001c67969340fbf8",
    "url": "/static/js/skins/ui/oxide-dark/content.inline.min.css"
  },
  {
    "revision": "40677b518a94b222613fd1d9cbd7675c",
    "url": "/static/js/skins/ui/oxide-dark/content.js"
  },
  {
    "revision": "7539d04a537482e9267b7ca3aab47e68",
    "url": "/static/js/skins/ui/oxide-dark/content.min.css"
  },
  {
    "revision": "d13d7efc94e47efa78e680bff3b4a5d5",
    "url": "/static/js/skins/ui/oxide-dark/skin.css"
  },
  {
    "revision": "2dfa54894a5b3d8c67681a0c4b37d223",
    "url": "/static/js/skins/ui/oxide-dark/skin.js"
  },
  {
    "revision": "e716d3f4b9e82608417208f2204e49ad",
    "url": "/static/js/skins/ui/oxide-dark/skin.min.css"
  },
  {
    "revision": "31792aa3530bea8433b3b50c8c38529f",
    "url": "/static/js/skins/ui/oxide-dark/skin.shadowdom.css"
  },
  {
    "revision": "72120558f3675559c6b7b5805af2f797",
    "url": "/static/js/skins/ui/oxide-dark/skin.shadowdom.js"
  },
  {
    "revision": "1448b0502cbc52a71d7b2a5eaa9f3847",
    "url": "/static/js/skins/ui/oxide-dark/skin.shadowdom.min.css"
  },
  {
    "revision": "bab3450f956ab5ce56aec6a7578abc15",
    "url": "/static/js/skins/ui/oxide/content.css"
  },
  {
    "revision": "d7cd93d57d013b0cc029f065d4006fda",
    "url": "/static/js/skins/ui/oxide/content.inline.css"
  },
  {
    "revision": "d4d57fa233e514f0cdff136e813cf706",
    "url": "/static/js/skins/ui/oxide/content.inline.js"
  },
  {
    "revision": "0120d4d3c9bb3dbf001c67969340fbf8",
    "url": "/static/js/skins/ui/oxide/content.inline.min.css"
  },
  {
    "revision": "6daee4a8d051a6c15a16a13021a8556f",
    "url": "/static/js/skins/ui/oxide/content.js"
  },
  {
    "revision": "4cf4f8e8302ae609209523b8089e6171",
    "url": "/static/js/skins/ui/oxide/content.min.css"
  },
  {
    "revision": "e5744ca1f6a29dee6d7b2fa5b0354132",
    "url": "/static/js/skins/ui/oxide/skin.css"
  },
  {
    "revision": "86ce088b3425a347c0f3a43a87e97f07",
    "url": "/static/js/skins/ui/oxide/skin.js"
  },
  {
    "revision": "89f4036980e53403cce89eddccb4c1e9",
    "url": "/static/js/skins/ui/oxide/skin.min.css"
  },
  {
    "revision": "31792aa3530bea8433b3b50c8c38529f",
    "url": "/static/js/skins/ui/oxide/skin.shadowdom.css"
  },
  {
    "revision": "b1b1c1d2ffa4b20b55c0c7ee9e99d8a7",
    "url": "/static/js/skins/ui/oxide/skin.shadowdom.js"
  },
  {
    "revision": "1448b0502cbc52a71d7b2a5eaa9f3847",
    "url": "/static/js/skins/ui/oxide/skin.shadowdom.min.css"
  },
  {
    "revision": "0e07e4d5a73e6a96ad16b956d9054cb9",
    "url": "/static/js/skins/ui/tinymce-5-dark/content.css"
  },
  {
    "revision": "d7cd93d57d013b0cc029f065d4006fda",
    "url": "/static/js/skins/ui/tinymce-5-dark/content.inline.css"
  },
  {
    "revision": "6918ca2469d2892566bcae0478824a6d",
    "url": "/static/js/skins/ui/tinymce-5-dark/content.inline.js"
  },
  {
    "revision": "0120d4d3c9bb3dbf001c67969340fbf8",
    "url": "/static/js/skins/ui/tinymce-5-dark/content.inline.min.css"
  },
  {
    "revision": "230e68cd78fd3877fb4941b30a8283f1",
    "url": "/static/js/skins/ui/tinymce-5-dark/content.js"
  },
  {
    "revision": "7539d04a537482e9267b7ca3aab47e68",
    "url": "/static/js/skins/ui/tinymce-5-dark/content.min.css"
  },
  {
    "revision": "50115eaa86afc2dccc00527efb6a11f1",
    "url": "/static/js/skins/ui/tinymce-5-dark/skin.css"
  },
  {
    "revision": "e777df000ebb217f06b7f4b2e01a41cf",
    "url": "/static/js/skins/ui/tinymce-5-dark/skin.js"
  },
  {
    "revision": "9a551bf21643a3abf3acbb2cbc2e6cd1",
    "url": "/static/js/skins/ui/tinymce-5-dark/skin.min.css"
  },
  {
    "revision": "31792aa3530bea8433b3b50c8c38529f",
    "url": "/static/js/skins/ui/tinymce-5-dark/skin.shadowdom.css"
  },
  {
    "revision": "319cad3f60383e10990464719c6ffff1",
    "url": "/static/js/skins/ui/tinymce-5-dark/skin.shadowdom.js"
  },
  {
    "revision": "1448b0502cbc52a71d7b2a5eaa9f3847",
    "url": "/static/js/skins/ui/tinymce-5-dark/skin.shadowdom.min.css"
  },
  {
    "revision": "bab3450f956ab5ce56aec6a7578abc15",
    "url": "/static/js/skins/ui/tinymce-5/content.css"
  },
  {
    "revision": "d7cd93d57d013b0cc029f065d4006fda",
    "url": "/static/js/skins/ui/tinymce-5/content.inline.css"
  },
  {
    "revision": "c5aa69c3f2bee5a74d52cea987a9d944",
    "url": "/static/js/skins/ui/tinymce-5/content.inline.js"
  },
  {
    "revision": "0120d4d3c9bb3dbf001c67969340fbf8",
    "url": "/static/js/skins/ui/tinymce-5/content.inline.min.css"
  },
  {
    "revision": "e1a98a4c330b82a6a5cb311a11ae1219",
    "url": "/static/js/skins/ui/tinymce-5/content.js"
  },
  {
    "revision": "4cf4f8e8302ae609209523b8089e6171",
    "url": "/static/js/skins/ui/tinymce-5/content.min.css"
  },
  {
    "revision": "bafa543a7357e7f9ffd408bd0276ab33",
    "url": "/static/js/skins/ui/tinymce-5/skin.css"
  },
  {
    "revision": "26e452a561e19e7da05e300a9a5ddf97",
    "url": "/static/js/skins/ui/tinymce-5/skin.js"
  },
  {
    "revision": "a7873ae454de7bb8e6d452c132cdf3a0",
    "url": "/static/js/skins/ui/tinymce-5/skin.min.css"
  },
  {
    "revision": "31792aa3530bea8433b3b50c8c38529f",
    "url": "/static/js/skins/ui/tinymce-5/skin.shadowdom.css"
  },
  {
    "revision": "5d5a39cb7d20b0e0512d33f028bdadcd",
    "url": "/static/js/skins/ui/tinymce-5/skin.shadowdom.js"
  },
  {
    "revision": "1448b0502cbc52a71d7b2a5eaa9f3847",
    "url": "/static/js/skins/ui/tinymce-5/skin.shadowdom.min.css"
  },
  {
    "revision": "7516fc313b953a9501c3ae0c58933f63",
    "url": "/static/manifest.json"
  },
  {
    "revision": "d056fffcc9a01dd7e42367cea88b6e7d",
    "url": "/static/robots.txt"
  },
  {
    "revision": "a6a54b44411ceaadc2a91e9cac8629dc",
    "url": "/static/service-worker.js"
  }
]);