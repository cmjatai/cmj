self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d44ac6d2a43c55274f04d4c050ed0692",
    "url": "/static/brasao/brasao_1024.png"
  },
  {
    "revision": "8f99e5ea64db3fcda01b117954e4af6f",
    "url": "/static/brasao/brasao_128.png"
  },
  {
    "revision": "6c307cb29fb97f80facd4199fb46d45f",
    "url": "/static/brasao/brasao_256.png"
  },
  {
    "revision": "2faeef56500a910abf40dd2d98ef9a99",
    "url": "/static/brasao/brasao_32.png"
  },
  {
    "revision": "7f74a84703400cee7e6807673fd939f8",
    "url": "/static/brasao/brasao_512.png"
  },
  {
    "revision": "f7b796ce23a9c65a82e199e56efded11",
    "url": "/static/brasao/brasao_64.png"
  },
  {
    "revision": "af0481c7b1c5abcdd249eccd2092870c",
    "url": "/static/brasao/escola_1024.png"
  },
  {
    "revision": "6e8caf69c10b43b72e52",
    "url": "/static/css/app.bdee5c0b.css"
  },
  {
    "revision": "331c4591ee4b65991c30",
    "url": "/static/css/chunk-0ec9d5db.1c736b92.css"
  },
  {
    "revision": "738c1735a91d9d10fb42",
    "url": "/static/css/chunk-2f6a5bb1.dcab6d0b.css"
  },
  {
    "revision": "2a89e546317564258a8e",
    "url": "/static/css/chunk-3d0ad08f.4af96183.css"
  },
  {
    "revision": "c3ba9e53558cb70d1367",
    "url": "/static/css/chunk-3ef0b8f8.1f33f65a.css"
  },
  {
    "revision": "0968c8679051720dbbac",
    "url": "/static/css/chunk-5fb8b196.2316f325.css"
  },
  {
    "revision": "8d52c93475785ba99c89",
    "url": "/static/css/chunk-6a4ef9e6.e32376be.css"
  },
  {
    "revision": "ef297d2ebfaa8fd0660c",
    "url": "/static/css/chunk-6f0ff250.55478430.css"
  },
  {
    "revision": "525ba4b0badd364f274c",
    "url": "/static/css/chunk-753c49cc.e0c63c90.css"
  },
  {
    "revision": "73fc5e7b2bc96e1b22c9",
    "url": "/static/css/chunk-vendors.effa1d48.css"
  },
  {
    "revision": "208eca601f16d8a98e93",
    "url": "/static/css/compilacao.b8c0b1a3.css"
  },
  {
    "revision": "c0c5c114f69fb7b01390",
    "url": "/static/css/construct.475dffe8.css"
  },
  {
    "revision": "27bc3a9d16c70a728701",
    "url": "/static/css/loa.19530300.css"
  },
  {
    "revision": "942025d6ac45441c4828",
    "url": "/static/css/painel.fd83c40d.css"
  },
  {
    "revision": "1a575a4138e5f366474f0e7c5bd614a5",
    "url": "/static/fonts/fa-brands-400.1a575a41.woff"
  },
  {
    "revision": "513aa607d398efaccc559916c3431403",
    "url": "/static/fonts/fa-brands-400.513aa607.ttf"
  },
  {
    "revision": "592643a83b8541edc52063d84c468700",
    "url": "/static/fonts/fa-brands-400.592643a8.eot"
  },
  {
    "revision": "ed311c7a0ade9a75bb3ebf5a7670f31d",
    "url": "/static/fonts/fa-brands-400.ed311c7a.woff2"
  },
  {
    "revision": "766913e6c0088ab8c9f73e18b4127bc4",
    "url": "/static/fonts/fa-regular-400.766913e6.ttf"
  },
  {
    "revision": "b0e2db3b634d1bc3928e127458d993d8",
    "url": "/static/fonts/fa-regular-400.b0e2db3b.eot"
  },
  {
    "revision": "b91d376b8d7646d671cd820950d5f7f1",
    "url": "/static/fonts/fa-regular-400.b91d376b.woff2"
  },
  {
    "revision": "d1d7e3b4c219fde0f7376c6facfd7149",
    "url": "/static/fonts/fa-regular-400.d1d7e3b4.woff"
  },
  {
    "revision": "0c6bfc668a72935760178f91327aed3a",
    "url": "/static/fonts/fa-solid-900.0c6bfc66.eot"
  },
  {
    "revision": "b9625119ce4300f0ef890a8f3234c773",
    "url": "/static/fonts/fa-solid-900.b9625119.ttf"
  },
  {
    "revision": "d745348d289b149026921f197929a893",
    "url": "/static/fonts/fa-solid-900.d745348d.woff"
  },
  {
    "revision": "d824df7eb2e268626a2dd9a6a741ac4e",
    "url": "/static/fonts/fa-solid-900.d824df7e.woff2"
  },
  {
    "revision": "7dff63695e03670336c6802fba347192",
    "url": "/static/img/arrow.png"
  },
  {
    "revision": "0e297f93ffa296cb2bf2782aa94e3268",
    "url": "/static/img/authenticated.png"
  },
  {
    "revision": "f0ce5b4a7afbc34f6a5b5451a18240a1",
    "url": "/static/img/avatar.png"
  },
  {
    "revision": "0fedfc17af66cfcd0beaab4a2beec61d",
    "url": "/static/img/beta.png"
  },
  {
    "revision": "4c35c324fbeb89c16b575c7381f70d6a",
    "url": "/static/img/bg.png"
  },
  {
    "revision": "39bca038c6e5e11e4f7c1e4ee3389c57",
    "url": "/static/img/bg_cmj_topo_menu_box_left.png"
  },
  {
    "revision": "e107ac1f05c9ef2c6c629807be229781",
    "url": "/static/img/bg_cmj_topo_menu_box_right.png"
  },
  {
    "revision": "849c15ec220a24e99aa8506601f41ba9",
    "url": "/static/img/brasao_transp.gif"
  },
  {
    "revision": "bb1e0825d5223704d2c295f4e1d86b91",
    "url": "/static/img/down_arrow_select.jpg"
  },
  {
    "revision": "587404969e0999831266a637b48aea4c",
    "url": "/static/img/etiqueta.png"
  },
  {
    "revision": "1d5619cd804367cefe6da2d79289218a",
    "url": "/static/img/fa-brands-400.1d5619cd.svg"
  },
  {
    "revision": "c5d109be8edd3de0f60eb472bd9ef691",
    "url": "/static/img/fa-regular-400.c5d109be.svg"
  },
  {
    "revision": "37bc7099f6f1ba80236164f22e905837",
    "url": "/static/img/fa-solid-900.37bc7099.svg"
  },
  {
    "revision": "93ba768be99c67b9030dfa2ed3fff325",
    "url": "/static/img/file.png"
  },
  {
    "revision": "64400f9f98b710c7fd5fd5fe737fa5da",
    "url": "/static/img/hand-note.png"
  },
  {
    "revision": "02a478243475dc9ba11c7f0915cfeb4b",
    "url": "/static/img/icon_comissoes.png"
  },
  {
    "revision": "40757133ae49b1a803785cd3b4d291d2",
    "url": "/static/img/icon_delete_white.png"
  },
  {
    "revision": "717405792fc232b5e210975822cac408",
    "url": "/static/img/icon_diario_oficial.png"
  },
  {
    "revision": "dbd3da2407bbb56f28b74d0ac573786d",
    "url": "/static/img/icon_facebook64x64.png"
  },
  {
    "revision": "761d394d64ef531b8abf8a9399ce46ff",
    "url": "/static/img/icon_favo.761d394d.svg"
  },
  {
    "revision": "c55a1bc2d99244a4c08aa448f361977b",
    "url": "/static/img/icon_instagram64x64.png"
  },
  {
    "revision": "db910d5dc2b1d30e05766228256eb03d",
    "url": "/static/img/icon_licitacao.png"
  },
  {
    "revision": "69067c48fb437e151a2f90d2290a70ee",
    "url": "/static/img/icon_materia_legislativa.png"
  },
  {
    "revision": "d9d48b974febd617d01b336974c30602",
    "url": "/static/img/icon_mesa_diretora.png"
  },
  {
    "revision": "52266702cd5f7dbdfa8024e799064a52",
    "url": "/static/img/icon_normas_juridicas.png"
  },
  {
    "revision": "d0c2cc179ab932fb24ea6258f61e6157",
    "url": "/static/img/icon_normas_juridicas_destaque.png"
  },
  {
    "revision": "aa171389861a663655fd834079f0d039",
    "url": "/static/img/icon_parlamentares.png"
  },
  {
    "revision": "0558a63d676cc435f2695119e12fdf5f",
    "url": "/static/img/icon_pautas.png"
  },
  {
    "revision": "f182e226a4ff6fe9408b616b02357cf0",
    "url": "/static/img/icon_plenarias.png"
  },
  {
    "revision": "02f6e0c106f20a7c6e21a7b523207f47",
    "url": "/static/img/icon_relatorios.png"
  },
  {
    "revision": "80baf13f86d26f847f3d1b7c7824d4ac",
    "url": "/static/img/icon_save_white.png"
  },
  {
    "revision": "c79840b15ffb49df44967f48807086b3",
    "url": "/static/img/icon_telegram64x64.png"
  },
  {
    "revision": "1d5eeaaa12bce45bbff08db8649e8236",
    "url": "/static/img/icon_transparencia.png"
  },
  {
    "revision": "ef54a640a5c60454a2e7453400bb474f",
    "url": "/static/img/icon_transparencia_prata.png"
  },
  {
    "revision": "2913dd0f6f0cb6715bccef36b0a1e834",
    "url": "/static/img/icon_twitter64x64.png"
  },
  {
    "revision": "aeb805abec46d148aad293ef9abffb79",
    "url": "/static/img/icon_whatsapp64x64.png"
  },
  {
    "revision": "014534399a6fb8befff55baa41e88f40",
    "url": "/static/img/icon_x_twitter.png"
  },
  {
    "revision": "f8e6bc697c257aa4fb5240c7dcbc97c4",
    "url": "/static/img/icon_x_twitter.svg"
  },
  {
    "revision": "c2e9627ea8ba42292971f91003af2490",
    "url": "/static/img/lexml.gif"
  },
  {
    "revision": "91a31efd0faa6d218e52775620e5280e",
    "url": "/static/img/logo.png"
  },
  {
    "revision": "8f99e5ea64db3fcda01b117954e4af6f",
    "url": "/static/img/logo_128.png"
  },
  {
    "revision": "317993f5074301653849e01d7650b1b3",
    "url": "/static/img/logo_cc.png"
  },
  {
    "revision": "06a3dea855d83cb8194e22ab2eabe198",
    "url": "/static/img/logo_cmj_redesocial.jpg"
  },
  {
    "revision": "59f2f9287bac78d247507ee5c5053dea",
    "url": "/static/img/logo_interlegis.png"
  },
  {
    "revision": "a1a5cb8ccda80ba8d2e53de044a749a0",
    "url": "/static/img/logo_sic.png"
  },
  {
    "revision": "8fbc3fa26d7f696fed113c2e72419a02",
    "url": "/static/img/manual.png"
  },
  {
    "revision": "296d5d8e05785fd7d04439e18e9ff91d",
    "url": "/static/img/pdf_cabec.jpg"
  },
  {
    "revision": "e86d4f3790dcba9d471b7d6ece42e48c",
    "url": "/static/img/pdf_cabec_margem.jpg"
  },
  {
    "revision": "c0e894ed8b441b6739133c2a7601150d",
    "url": "/static/img/pdf_rodape.jpg"
  },
  {
    "revision": "64679dab3b056be7ac0c73409f963fcb",
    "url": "/static/img/pdf_rodape_margem.jpg"
  },
  {
    "revision": "fb71e48b2330408afac41e0bcfbbd4c0",
    "url": "/static/img/pdflogo.png"
  },
  {
    "revision": "394e657c181354ac1b5c43ce799909a6",
    "url": "/static/img/perfil.1.jpg"
  },
  {
    "revision": "394e657c181354ac1b5c43ce799909a6",
    "url": "/static/img/perfil.jpg"
  },
  {
    "revision": "43b8081d408cea9bc8e27d99fd8636ae",
    "url": "/static/img/perfil.png"
  },
  {
    "revision": "6dc51af6e7a5ac30728639f3cdf62804",
    "url": "/static/img/search-gray.png"
  },
  {
    "revision": "2e90e4927047c60bf57d947fd87a824b",
    "url": "/static/img/search.png"
  },
  {
    "revision": "dbb46e053254b0e6a8fc2488275dd6be",
    "url": "/static/img/search_box_icon36.png"
  },
  {
    "revision": "dbb46e053254b0e6a8fc2488275dd6be",
    "url": "/static/img/search_box_icon36_delete.png"
  },
  {
    "revision": "9a0717578fe8e07bbd512ec97725cdc0",
    "url": "/static/img/user.png"
  },
  {
    "revision": "18dae7754d7396b3b4aea7774efe173a",
    "url": "/static/index.html"
  },
  {
    "revision": "6e8caf69c10b43b72e52",
    "url": "/static/js/app.016ce923.js"
  },
  {
    "revision": "331c4591ee4b65991c30",
    "url": "/static/js/chunk-0ec9d5db.8e7f0538.js"
  },
  {
    "revision": "fa6c73a49517b8c0f220",
    "url": "/static/js/chunk-2d0cb66a.ca4f82c0.js"
  },
  {
    "revision": "3a660e3a559bd6541868",
    "url": "/static/js/chunk-2d216bf1.112498bd.js"
  },
  {
    "revision": "738c1735a91d9d10fb42",
    "url": "/static/js/chunk-2f6a5bb1.c88d20f9.js"
  },
  {
    "revision": "2a89e546317564258a8e",
    "url": "/static/js/chunk-3d0ad08f.c180d40e.js"
  },
  {
    "revision": "c3ba9e53558cb70d1367",
    "url": "/static/js/chunk-3ef0b8f8.1c5e48d1.js"
  },
  {
    "revision": "0968c8679051720dbbac",
    "url": "/static/js/chunk-5fb8b196.959c49f8.js"
  },
  {
    "revision": "8d52c93475785ba99c89",
    "url": "/static/js/chunk-6a4ef9e6.1780946a.js"
  },
  {
    "revision": "ef297d2ebfaa8fd0660c",
    "url": "/static/js/chunk-6f0ff250.eb4d24be.js"
  },
  {
    "revision": "525ba4b0badd364f274c",
    "url": "/static/js/chunk-753c49cc.3790e50b.js"
  },
  {
    "revision": "904dc4c5f111b793c329",
    "url": "/static/js/chunk-7a782422.4e4ccdaa.js"
  },
  {
    "revision": "e6a1c347ff0c1140f137",
    "url": "/static/js/chunk-8a7d5ae8.93e9089c.js"
  },
  {
    "revision": "73fc5e7b2bc96e1b22c9",
    "url": "/static/js/chunk-vendors.eb525c5d.js"
  },
  {
    "revision": "208eca601f16d8a98e93",
    "url": "/static/js/compilacao.59b5b9d1.js"
  },
  {
    "revision": "c0c5c114f69fb7b01390",
    "url": "/static/js/construct.c3b8a301.js"
  },
  {
    "revision": "27bc3a9d16c70a728701",
    "url": "/static/js/loa.ce48e90c.js"
  },
  {
    "revision": "942025d6ac45441c4828",
    "url": "/static/js/painel.e2c09202.js"
  },
  {
    "revision": "c18a991f9ef0b423adb8b1b132afea6c",
    "url": "/static/js/skins/content/dark/content.css"
  },
  {
    "revision": "38b9cd18bbec1e79964f94f79df8d322",
    "url": "/static/js/skins/content/dark/content.js"
  },
  {
    "revision": "8be098c8a09616b6f37f8ed7c963ebca",
    "url": "/static/js/skins/content/dark/content.min.css"
  },
  {
    "revision": "fdd392b36001c3e0f925e00869fab674",
    "url": "/static/js/skins/content/default/content.css"
  },
  {
    "revision": "f014cdd3dc76c820424ea0c13706b527",
    "url": "/static/js/skins/content/default/content.js"
  },
  {
    "revision": "e7448307845064b6e567dabdf0edd81a",
    "url": "/static/js/skins/content/default/content.min.css"
  },
  {
    "revision": "d6e36fda2726c056c0782b7f0e0d3a33",
    "url": "/static/js/skins/content/document/content.css"
  },
  {
    "revision": "e133bc2114fa6bd3fb9e6404d5858e40",
    "url": "/static/js/skins/content/document/content.js"
  },
  {
    "revision": "6cb27dc9ba941235eb2b074c9cbf7126",
    "url": "/static/js/skins/content/document/content.min.css"
  },
  {
    "revision": "4d9f0e703d7e35ede12e5cc6916ff75b",
    "url": "/static/js/skins/content/tinymce-5-dark/content.css"
  },
  {
    "revision": "445fd0a046091300c16b598738f48267",
    "url": "/static/js/skins/content/tinymce-5-dark/content.js"
  },
  {
    "revision": "4e7d595a3352a317ac5457e1544dd018",
    "url": "/static/js/skins/content/tinymce-5-dark/content.min.css"
  },
  {
    "revision": "fdd392b36001c3e0f925e00869fab674",
    "url": "/static/js/skins/content/tinymce-5/content.css"
  },
  {
    "revision": "97d1c5e4a709a49fd6f89552fc2e5f87",
    "url": "/static/js/skins/content/tinymce-5/content.js"
  },
  {
    "revision": "e7448307845064b6e567dabdf0edd81a",
    "url": "/static/js/skins/content/tinymce-5/content.min.css"
  },
  {
    "revision": "54891f08e9425ba6cfc8285c320f4394",
    "url": "/static/js/skins/content/writer/content.css"
  },
  {
    "revision": "f11cb3b267cb6d8ede6190a1b736e02a",
    "url": "/static/js/skins/content/writer/content.js"
  },
  {
    "revision": "5647767d1db4e7cbfe47ab7510c8aeea",
    "url": "/static/js/skins/content/writer/content.min.css"
  },
  {
    "revision": "d7033ed8451deee010d842dedef444a2",
    "url": "/static/js/skins/ui/oxide-dark/content.css"
  },
  {
    "revision": "27d1ca7e96271872549b2c4b2e84bdce",
    "url": "/static/js/skins/ui/oxide-dark/content.inline.css"
  },
  {
    "revision": "373bb7d99726913f8120c0555cebb6f8",
    "url": "/static/js/skins/ui/oxide-dark/content.inline.js"
  },
  {
    "revision": "49505a47fe9b579d50f0f8552395083f",
    "url": "/static/js/skins/ui/oxide-dark/content.inline.min.css"
  },
  {
    "revision": "3df7afc5867ab98923476acb9cf4ac62",
    "url": "/static/js/skins/ui/oxide-dark/content.js"
  },
  {
    "revision": "7cbdcedf49b95a00e4f8fd56e477f3f3",
    "url": "/static/js/skins/ui/oxide-dark/content.min.css"
  },
  {
    "revision": "72faeea7aa7e97d573b2d97bcdac4029",
    "url": "/static/js/skins/ui/oxide-dark/skin.css"
  },
  {
    "revision": "dbe33d2b1337b631e3bdb573616f2919",
    "url": "/static/js/skins/ui/oxide-dark/skin.js"
  },
  {
    "revision": "5dbea65bdf09d52833fe8b9ce461b351",
    "url": "/static/js/skins/ui/oxide-dark/skin.min.css"
  },
  {
    "revision": "31792aa3530bea8433b3b50c8c38529f",
    "url": "/static/js/skins/ui/oxide-dark/skin.shadowdom.css"
  },
  {
    "revision": "e96d3c218f2b79f82e2c87b6f3f818bb",
    "url": "/static/js/skins/ui/oxide-dark/skin.shadowdom.js"
  },
  {
    "revision": "1448b0502cbc52a71d7b2a5eaa9f3847",
    "url": "/static/js/skins/ui/oxide-dark/skin.shadowdom.min.css"
  },
  {
    "revision": "08442f05490bb740f82b1891f6402823",
    "url": "/static/js/skins/ui/oxide/content.css"
  },
  {
    "revision": "27d1ca7e96271872549b2c4b2e84bdce",
    "url": "/static/js/skins/ui/oxide/content.inline.css"
  },
  {
    "revision": "3f0be162016332ee4531e850108d0515",
    "url": "/static/js/skins/ui/oxide/content.inline.js"
  },
  {
    "revision": "49505a47fe9b579d50f0f8552395083f",
    "url": "/static/js/skins/ui/oxide/content.inline.min.css"
  },
  {
    "revision": "c38d0f9816d2d6a5fb45e792a0dff5f9",
    "url": "/static/js/skins/ui/oxide/content.js"
  },
  {
    "revision": "ca6fb6cec416a25e1cf470672e2e9ba2",
    "url": "/static/js/skins/ui/oxide/content.min.css"
  },
  {
    "revision": "3c175a42023a3b6d84689403909f8923",
    "url": "/static/js/skins/ui/oxide/skin.css"
  },
  {
    "revision": "3ff572a458d13816c0dcc8214e77c814",
    "url": "/static/js/skins/ui/oxide/skin.js"
  },
  {
    "revision": "42bb17f080ec725a852cfe06f8192225",
    "url": "/static/js/skins/ui/oxide/skin.min.css"
  },
  {
    "revision": "31792aa3530bea8433b3b50c8c38529f",
    "url": "/static/js/skins/ui/oxide/skin.shadowdom.css"
  },
  {
    "revision": "fb3cc71941cdc2e83de399ee39abe36d",
    "url": "/static/js/skins/ui/oxide/skin.shadowdom.js"
  },
  {
    "revision": "1448b0502cbc52a71d7b2a5eaa9f3847",
    "url": "/static/js/skins/ui/oxide/skin.shadowdom.min.css"
  },
  {
    "revision": "b7dc8a59c9b884fba03d945f10b807f6",
    "url": "/static/js/skins/ui/tinymce-5-dark/content.css"
  },
  {
    "revision": "27d1ca7e96271872549b2c4b2e84bdce",
    "url": "/static/js/skins/ui/tinymce-5-dark/content.inline.css"
  },
  {
    "revision": "24d521747888ac23eb73b77397552e05",
    "url": "/static/js/skins/ui/tinymce-5-dark/content.inline.js"
  },
  {
    "revision": "49505a47fe9b579d50f0f8552395083f",
    "url": "/static/js/skins/ui/tinymce-5-dark/content.inline.min.css"
  },
  {
    "revision": "756dbfcbdc88adab0f43c0aec54409e1",
    "url": "/static/js/skins/ui/tinymce-5-dark/content.js"
  },
  {
    "revision": "d94b061c55ba7a0b8ba4f97c47d12348",
    "url": "/static/js/skins/ui/tinymce-5-dark/content.min.css"
  },
  {
    "revision": "29ae73190896f0b8b97367f56008f57b",
    "url": "/static/js/skins/ui/tinymce-5-dark/skin.css"
  },
  {
    "revision": "a816f7f2bf86993208481df3e78aa3eb",
    "url": "/static/js/skins/ui/tinymce-5-dark/skin.js"
  },
  {
    "revision": "966b88eb97e569c78fccd7ca59b44173",
    "url": "/static/js/skins/ui/tinymce-5-dark/skin.min.css"
  },
  {
    "revision": "31792aa3530bea8433b3b50c8c38529f",
    "url": "/static/js/skins/ui/tinymce-5-dark/skin.shadowdom.css"
  },
  {
    "revision": "eb127cec1c96aebc630b4f9f5efcbf7e",
    "url": "/static/js/skins/ui/tinymce-5-dark/skin.shadowdom.js"
  },
  {
    "revision": "1448b0502cbc52a71d7b2a5eaa9f3847",
    "url": "/static/js/skins/ui/tinymce-5-dark/skin.shadowdom.min.css"
  },
  {
    "revision": "08442f05490bb740f82b1891f6402823",
    "url": "/static/js/skins/ui/tinymce-5/content.css"
  },
  {
    "revision": "27d1ca7e96271872549b2c4b2e84bdce",
    "url": "/static/js/skins/ui/tinymce-5/content.inline.css"
  },
  {
    "revision": "9b77034e38225961acab5c6ee413c785",
    "url": "/static/js/skins/ui/tinymce-5/content.inline.js"
  },
  {
    "revision": "49505a47fe9b579d50f0f8552395083f",
    "url": "/static/js/skins/ui/tinymce-5/content.inline.min.css"
  },
  {
    "revision": "0909346613701fd584f87388e5dc8cf4",
    "url": "/static/js/skins/ui/tinymce-5/content.js"
  },
  {
    "revision": "ca6fb6cec416a25e1cf470672e2e9ba2",
    "url": "/static/js/skins/ui/tinymce-5/content.min.css"
  },
  {
    "revision": "856b2f9db18d36d3dc5747c10876e0b0",
    "url": "/static/js/skins/ui/tinymce-5/skin.css"
  },
  {
    "revision": "df079306a9d4c152736a5176d7b0b225",
    "url": "/static/js/skins/ui/tinymce-5/skin.js"
  },
  {
    "revision": "4eb517ddd14546234c63b0c5a5ee2237",
    "url": "/static/js/skins/ui/tinymce-5/skin.min.css"
  },
  {
    "revision": "31792aa3530bea8433b3b50c8c38529f",
    "url": "/static/js/skins/ui/tinymce-5/skin.shadowdom.css"
  },
  {
    "revision": "7d0e89599f3017f7e3941b47f71afee3",
    "url": "/static/js/skins/ui/tinymce-5/skin.shadowdom.js"
  },
  {
    "revision": "1448b0502cbc52a71d7b2a5eaa9f3847",
    "url": "/static/js/skins/ui/tinymce-5/skin.shadowdom.min.css"
  },
  {
    "revision": "a0f2247a0047149e2a62a059c7319a6e",
    "url": "/static/manifest.json"
  },
  {
    "revision": "3d798458ee267f228251ca2b111181ba",
    "url": "/static/robots.txt"
  },
  {
    "revision": "947b162e16466adbff5f6c878d6cd521",
    "url": "/static/service-worker.js"
  }
]);