self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d44ac6d2a43c55274f04d4c050ed0692",
    "url": "/static/brasao/brasao_1024.png"
  },
  {
    "revision": "8f99e5ea64db3fcda01b117954e4af6f",
    "url": "/static/brasao/brasao_128.png"
  },
  {
    "revision": "6c307cb29fb97f80facd4199fb46d45f",
    "url": "/static/brasao/brasao_256.png"
  },
  {
    "revision": "2faeef56500a910abf40dd2d98ef9a99",
    "url": "/static/brasao/brasao_32.png"
  },
  {
    "revision": "7f74a84703400cee7e6807673fd939f8",
    "url": "/static/brasao/brasao_512.png"
  },
  {
    "revision": "f7b796ce23a9c65a82e199e56efded11",
    "url": "/static/brasao/brasao_64.png"
  },
  {
    "revision": "af0481c7b1c5abcdd249eccd2092870c",
    "url": "/static/brasao/escola_1024.png"
  },
  {
    "revision": "4cd838d6a73179ef9d80",
    "url": "/static/css/app.5f8715c8.css"
  },
  {
    "revision": "2d9dcc9be90ce85c13d2",
    "url": "/static/css/chunk-16e961fe.c9d1e1e5.css"
  },
  {
    "revision": "9609ed47c795aafb76d5",
    "url": "/static/css/chunk-227d0a6e.79a56ae1.css"
  },
  {
    "revision": "90997d8c87ab403d1ff1",
    "url": "/static/css/chunk-38d06efb.d4696fb9.css"
  },
  {
    "revision": "3558c2cd741085d00c4f",
    "url": "/static/css/chunk-f11218b8.707facdf.css"
  },
  {
    "revision": "805986cda559663a2be2",
    "url": "/static/css/chunk-vendors.7cbba22c.css"
  },
  {
    "revision": "086e6bb842ace4ba2cd9",
    "url": "/static/css/compilacao.a246a51d.css"
  },
  {
    "revision": "94ade09668e0b2765ee0",
    "url": "/static/css/construct.6cb1e7d1.css"
  },
  {
    "revision": "68920a17224f54fb4465",
    "url": "/static/css/painel.fd83c40d.css"
  },
  {
    "revision": "1a575a4138e5f366474f0e7c5bd614a5",
    "url": "/static/fonts/fa-brands-400.1a575a41.woff"
  },
  {
    "revision": "513aa607d398efaccc559916c3431403",
    "url": "/static/fonts/fa-brands-400.513aa607.ttf"
  },
  {
    "revision": "592643a83b8541edc52063d84c468700",
    "url": "/static/fonts/fa-brands-400.592643a8.eot"
  },
  {
    "revision": "ed311c7a0ade9a75bb3ebf5a7670f31d",
    "url": "/static/fonts/fa-brands-400.ed311c7a.woff2"
  },
  {
    "revision": "766913e6c0088ab8c9f73e18b4127bc4",
    "url": "/static/fonts/fa-regular-400.766913e6.ttf"
  },
  {
    "revision": "b0e2db3b634d1bc3928e127458d993d8",
    "url": "/static/fonts/fa-regular-400.b0e2db3b.eot"
  },
  {
    "revision": "b91d376b8d7646d671cd820950d5f7f1",
    "url": "/static/fonts/fa-regular-400.b91d376b.woff2"
  },
  {
    "revision": "d1d7e3b4c219fde0f7376c6facfd7149",
    "url": "/static/fonts/fa-regular-400.d1d7e3b4.woff"
  },
  {
    "revision": "0c6bfc668a72935760178f91327aed3a",
    "url": "/static/fonts/fa-solid-900.0c6bfc66.eot"
  },
  {
    "revision": "b9625119ce4300f0ef890a8f3234c773",
    "url": "/static/fonts/fa-solid-900.b9625119.ttf"
  },
  {
    "revision": "d745348d289b149026921f197929a893",
    "url": "/static/fonts/fa-solid-900.d745348d.woff"
  },
  {
    "revision": "d824df7eb2e268626a2dd9a6a741ac4e",
    "url": "/static/fonts/fa-solid-900.d824df7e.woff2"
  },
  {
    "revision": "7dff63695e03670336c6802fba347192",
    "url": "/static/img/arrow.png"
  },
  {
    "revision": "0e297f93ffa296cb2bf2782aa94e3268",
    "url": "/static/img/authenticated.png"
  },
  {
    "revision": "f0ce5b4a7afbc34f6a5b5451a18240a1",
    "url": "/static/img/avatar.png"
  },
  {
    "revision": "0fedfc17af66cfcd0beaab4a2beec61d",
    "url": "/static/img/beta.png"
  },
  {
    "revision": "4c35c324fbeb89c16b575c7381f70d6a",
    "url": "/static/img/bg.png"
  },
  {
    "revision": "39bca038c6e5e11e4f7c1e4ee3389c57",
    "url": "/static/img/bg_cmj_topo_menu_box_left.png"
  },
  {
    "revision": "e107ac1f05c9ef2c6c629807be229781",
    "url": "/static/img/bg_cmj_topo_menu_box_right.png"
  },
  {
    "revision": "849c15ec220a24e99aa8506601f41ba9",
    "url": "/static/img/brasao_transp.gif"
  },
  {
    "revision": "bb1e0825d5223704d2c295f4e1d86b91",
    "url": "/static/img/down_arrow_select.jpg"
  },
  {
    "revision": "587404969e0999831266a637b48aea4c",
    "url": "/static/img/etiqueta.png"
  },
  {
    "revision": "1d5619cd804367cefe6da2d79289218a",
    "url": "/static/img/fa-brands-400.1d5619cd.svg"
  },
  {
    "revision": "c5d109be8edd3de0f60eb472bd9ef691",
    "url": "/static/img/fa-regular-400.c5d109be.svg"
  },
  {
    "revision": "37bc7099f6f1ba80236164f22e905837",
    "url": "/static/img/fa-solid-900.37bc7099.svg"
  },
  {
    "revision": "93ba768be99c67b9030dfa2ed3fff325",
    "url": "/static/img/file.png"
  },
  {
    "revision": "64400f9f98b710c7fd5fd5fe737fa5da",
    "url": "/static/img/hand-note.png"
  },
  {
    "revision": "02a478243475dc9ba11c7f0915cfeb4b",
    "url": "/static/img/icon_comissoes.png"
  },
  {
    "revision": "40757133ae49b1a803785cd3b4d291d2",
    "url": "/static/img/icon_delete_white.png"
  },
  {
    "revision": "717405792fc232b5e210975822cac408",
    "url": "/static/img/icon_diario_oficial.png"
  },
  {
    "revision": "dbd3da2407bbb56f28b74d0ac573786d",
    "url": "/static/img/icon_facebook64x64.png"
  },
  {
    "revision": "c55a1bc2d99244a4c08aa448f361977b",
    "url": "/static/img/icon_instagram64x64.png"
  },
  {
    "revision": "db910d5dc2b1d30e05766228256eb03d",
    "url": "/static/img/icon_licitacao.png"
  },
  {
    "revision": "69067c48fb437e151a2f90d2290a70ee",
    "url": "/static/img/icon_materia_legislativa.png"
  },
  {
    "revision": "d9d48b974febd617d01b336974c30602",
    "url": "/static/img/icon_mesa_diretora.png"
  },
  {
    "revision": "52266702cd5f7dbdfa8024e799064a52",
    "url": "/static/img/icon_normas_juridicas.png"
  },
  {
    "revision": "d0c2cc179ab932fb24ea6258f61e6157",
    "url": "/static/img/icon_normas_juridicas_destaque.png"
  },
  {
    "revision": "aa171389861a663655fd834079f0d039",
    "url": "/static/img/icon_parlamentares.png"
  },
  {
    "revision": "0558a63d676cc435f2695119e12fdf5f",
    "url": "/static/img/icon_pautas.png"
  },
  {
    "revision": "f182e226a4ff6fe9408b616b02357cf0",
    "url": "/static/img/icon_plenarias.png"
  },
  {
    "revision": "02f6e0c106f20a7c6e21a7b523207f47",
    "url": "/static/img/icon_relatorios.png"
  },
  {
    "revision": "80baf13f86d26f847f3d1b7c7824d4ac",
    "url": "/static/img/icon_save_white.png"
  },
  {
    "revision": "1d5eeaaa12bce45bbff08db8649e8236",
    "url": "/static/img/icon_transparencia.png"
  },
  {
    "revision": "2913dd0f6f0cb6715bccef36b0a1e834",
    "url": "/static/img/icon_twitter64x64.png"
  },
  {
    "revision": "aeb805abec46d148aad293ef9abffb79",
    "url": "/static/img/icon_whatsapp64x64.png"
  },
  {
    "revision": "c2e9627ea8ba42292971f91003af2490",
    "url": "/static/img/lexml.gif"
  },
  {
    "revision": "91a31efd0faa6d218e52775620e5280e",
    "url": "/static/img/logo.png"
  },
  {
    "revision": "8f99e5ea64db3fcda01b117954e4af6f",
    "url": "/static/img/logo_128.png"
  },
  {
    "revision": "317993f5074301653849e01d7650b1b3",
    "url": "/static/img/logo_cc.png"
  },
  {
    "revision": "06a3dea855d83cb8194e22ab2eabe198",
    "url": "/static/img/logo_cmj_redesocial.jpg"
  },
  {
    "revision": "59f2f9287bac78d247507ee5c5053dea",
    "url": "/static/img/logo_interlegis.png"
  },
  {
    "revision": "a1a5cb8ccda80ba8d2e53de044a749a0",
    "url": "/static/img/logo_sic.png"
  },
  {
    "revision": "8fbc3fa26d7f696fed113c2e72419a02",
    "url": "/static/img/manual.png"
  },
  {
    "revision": "296d5d8e05785fd7d04439e18e9ff91d",
    "url": "/static/img/pdf_cabec.jpg"
  },
  {
    "revision": "c0e894ed8b441b6739133c2a7601150d",
    "url": "/static/img/pdf_rodape.jpg"
  },
  {
    "revision": "fb71e48b2330408afac41e0bcfbbd4c0",
    "url": "/static/img/pdflogo.png"
  },
  {
    "revision": "394e657c181354ac1b5c43ce799909a6",
    "url": "/static/img/perfil.1.jpg"
  },
  {
    "revision": "394e657c181354ac1b5c43ce799909a6",
    "url": "/static/img/perfil.jpg"
  },
  {
    "revision": "43b8081d408cea9bc8e27d99fd8636ae",
    "url": "/static/img/perfil.png"
  },
  {
    "revision": "6dc51af6e7a5ac30728639f3cdf62804",
    "url": "/static/img/search-gray.png"
  },
  {
    "revision": "2e90e4927047c60bf57d947fd87a824b",
    "url": "/static/img/search.png"
  },
  {
    "revision": "dbb46e053254b0e6a8fc2488275dd6be",
    "url": "/static/img/search_box_icon36.png"
  },
  {
    "revision": "dbb46e053254b0e6a8fc2488275dd6be",
    "url": "/static/img/search_box_icon36_delete.png"
  },
  {
    "revision": "9a0717578fe8e07bbd512ec97725cdc0",
    "url": "/static/img/user.png"
  },
  {
    "revision": "877efe8c53d884bafb976d7390b781ae",
    "url": "/static/index.html"
  },
  {
    "revision": "4cd838d6a73179ef9d80",
    "url": "/static/js/app.f3f7e95a.js"
  },
  {
    "revision": "2d9dcc9be90ce85c13d2",
    "url": "/static/js/chunk-16e961fe.a84411af.js"
  },
  {
    "revision": "9609ed47c795aafb76d5",
    "url": "/static/js/chunk-227d0a6e.7081e7aa.js"
  },
  {
    "revision": "4032ab618f85925d7d34",
    "url": "/static/js/chunk-2d0c4a82.d6526175.js"
  },
  {
    "revision": "90997d8c87ab403d1ff1",
    "url": "/static/js/chunk-38d06efb.f973e15d.js"
  },
  {
    "revision": "3558c2cd741085d00c4f",
    "url": "/static/js/chunk-f11218b8.cf0b133d.js"
  },
  {
    "revision": "805986cda559663a2be2",
    "url": "/static/js/chunk-vendors.a319ae66.js"
  },
  {
    "revision": "086e6bb842ace4ba2cd9",
    "url": "/static/js/compilacao.608d2d2f.js"
  },
  {
    "revision": "94ade09668e0b2765ee0",
    "url": "/static/js/construct.600a1065.js"
  },
  {
    "revision": "68920a17224f54fb4465",
    "url": "/static/js/painel.5fec57b6.js"
  },
  {
    "revision": "abdd83f838fac3428c028294f27efc4e",
    "url": "/static/js/skins/content/dark/content.css"
  },
  {
    "revision": "4c0b8cf274d116c2ff8b3f1c7cfaf9d3",
    "url": "/static/js/skins/content/dark/content.min.css"
  },
  {
    "revision": "db31e42bcf1c9c26eb3c9281816a3b33",
    "url": "/static/js/skins/content/default/content.css"
  },
  {
    "revision": "5022f9908e1f0680cdc3ad293816bd13",
    "url": "/static/js/skins/content/default/content.min.css"
  },
  {
    "revision": "24d66dddf2faa9f48de40df30ae8f1fc",
    "url": "/static/js/skins/content/document/content.css"
  },
  {
    "revision": "0ccaf40378ed037f42d01279f625793d",
    "url": "/static/js/skins/content/document/content.min.css"
  },
  {
    "revision": "3cd6fb97c8178ed816ce946d8b601ffa",
    "url": "/static/js/skins/content/writer/content.css"
  },
  {
    "revision": "856c1120d71e64f227e546a9406587f6",
    "url": "/static/js/skins/content/writer/content.min.css"
  },
  {
    "revision": "3be1a5f9b751d429f96ef9f805f645f0",
    "url": "/static/js/skins/ui/oxide-dark/content.css"
  },
  {
    "revision": "962c5a48fb9d7abd816aea47585ef416",
    "url": "/static/js/skins/ui/oxide-dark/content.inline.css"
  },
  {
    "revision": "22d0980afc1f368d8008259787dd9d77",
    "url": "/static/js/skins/ui/oxide-dark/content.inline.min.css"
  },
  {
    "revision": "23903b9d6f5e05ea73ad37d86a7e2f1f",
    "url": "/static/js/skins/ui/oxide-dark/content.min.css"
  },
  {
    "revision": "e84062c0d71bace6637586be7c2590d3",
    "url": "/static/js/skins/ui/oxide-dark/content.mobile.css"
  },
  {
    "revision": "411c2608b6be78849a76c0ed14200234",
    "url": "/static/js/skins/ui/oxide-dark/content.mobile.min.css"
  },
  {
    "revision": "baecf466c40e709e7ffdbc935fc0813a",
    "url": "/static/js/skins/ui/oxide-dark/fonts/tinymce-mobile.woff"
  },
  {
    "revision": "fda7bcb24e6cee9878e5bb2924363037",
    "url": "/static/js/skins/ui/oxide-dark/skin.css"
  },
  {
    "revision": "9e3824fbdfc20507fdd32cb445b34a40",
    "url": "/static/js/skins/ui/oxide-dark/skin.min.css"
  },
  {
    "revision": "338b06826c0e8a681688fc195dbb72b1",
    "url": "/static/js/skins/ui/oxide-dark/skin.mobile.css"
  },
  {
    "revision": "4fdf33191102d7a24a5bf0639040d128",
    "url": "/static/js/skins/ui/oxide-dark/skin.mobile.min.css"
  },
  {
    "revision": "c057b5684281b6280361ce90be8ea85d",
    "url": "/static/js/skins/ui/oxide-dark/skin.shadowdom.css"
  },
  {
    "revision": "e27cb72c7ae5f366b06a2e2c738ce733",
    "url": "/static/js/skins/ui/oxide-dark/skin.shadowdom.min.css"
  },
  {
    "revision": "ce4a792622c63bd4dc881d1c220e541b",
    "url": "/static/js/skins/ui/oxide/content.css"
  },
  {
    "revision": "962c5a48fb9d7abd816aea47585ef416",
    "url": "/static/js/skins/ui/oxide/content.inline.css"
  },
  {
    "revision": "22d0980afc1f368d8008259787dd9d77",
    "url": "/static/js/skins/ui/oxide/content.inline.min.css"
  },
  {
    "revision": "6de47628a73ed8bc258f96e9edfa29d7",
    "url": "/static/js/skins/ui/oxide/content.min.css"
  },
  {
    "revision": "e84062c0d71bace6637586be7c2590d3",
    "url": "/static/js/skins/ui/oxide/content.mobile.css"
  },
  {
    "revision": "411c2608b6be78849a76c0ed14200234",
    "url": "/static/js/skins/ui/oxide/content.mobile.min.css"
  },
  {
    "revision": "baecf466c40e709e7ffdbc935fc0813a",
    "url": "/static/js/skins/ui/oxide/fonts/tinymce-mobile.woff"
  },
  {
    "revision": "14a823cb74320ce638c8068fb1ff47e8",
    "url": "/static/js/skins/ui/oxide/skin.css"
  },
  {
    "revision": "40292756e45aaf491b954f5c323c4587",
    "url": "/static/js/skins/ui/oxide/skin.min.css"
  },
  {
    "revision": "338b06826c0e8a681688fc195dbb72b1",
    "url": "/static/js/skins/ui/oxide/skin.mobile.css"
  },
  {
    "revision": "4fdf33191102d7a24a5bf0639040d128",
    "url": "/static/js/skins/ui/oxide/skin.mobile.min.css"
  },
  {
    "revision": "c057b5684281b6280361ce90be8ea85d",
    "url": "/static/js/skins/ui/oxide/skin.shadowdom.css"
  },
  {
    "revision": "e27cb72c7ae5f366b06a2e2c738ce733",
    "url": "/static/js/skins/ui/oxide/skin.shadowdom.min.css"
  },
  {
    "revision": "7516fc313b953a9501c3ae0c58933f63",
    "url": "/static/manifest.json"
  },
  {
    "revision": "4fe4cddc853459bb91c805050c40f25e",
    "url": "/static/robots.txt"
  },
  {
    "revision": "a86f9f2ebe3931d7b46e266c05625689",
    "url": "/static/service-worker.js"
  }
]);