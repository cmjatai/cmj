self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d44ac6d2a43c55274f04d4c050ed0692",
    "url": "/static/brasao/brasao_1024.png"
  },
  {
    "revision": "8f99e5ea64db3fcda01b117954e4af6f",
    "url": "/static/brasao/brasao_128.png"
  },
  {
    "revision": "6c307cb29fb97f80facd4199fb46d45f",
    "url": "/static/brasao/brasao_256.png"
  },
  {
    "revision": "2faeef56500a910abf40dd2d98ef9a99",
    "url": "/static/brasao/brasao_32.png"
  },
  {
    "revision": "7f74a84703400cee7e6807673fd939f8",
    "url": "/static/brasao/brasao_512.png"
  },
  {
    "revision": "f7b796ce23a9c65a82e199e56efded11",
    "url": "/static/brasao/brasao_64.png"
  },
  {
    "revision": "af0481c7b1c5abcdd249eccd2092870c",
    "url": "/static/brasao/escola_1024.png"
  },
  {
    "revision": "49535e7b79d21186b1db",
    "url": "/static/css/app.65230ae6.css"
  },
  {
    "revision": "563f2d735e2604263813",
    "url": "/static/css/chunk-060d195a.e32376be.css"
  },
  {
    "revision": "fdd13f0ae39144aded8e",
    "url": "/static/css/chunk-4dfc392a.043a2397.css"
  },
  {
    "revision": "0a37eedddb8f58b53f58",
    "url": "/static/css/chunk-5d5a309a.245afcfd.css"
  },
  {
    "revision": "70d89936a9118b42c2e2",
    "url": "/static/css/chunk-5fb8b196.2316f325.css"
  },
  {
    "revision": "277a3467b32f24b3927d",
    "url": "/static/css/chunk-6f0ff250.55478430.css"
  },
  {
    "revision": "f1e65c0f871bb6e67e3f",
    "url": "/static/css/chunk-789e69d2.dcab6d0b.css"
  },
  {
    "revision": "bc43edc45efff4503bf2",
    "url": "/static/css/chunk-78b028b8.4af96183.css"
  },
  {
    "revision": "45274a22ece734bf993a",
    "url": "/static/css/chunk-f3b7518c.7c557d58.css"
  },
  {
    "revision": "cedbbe2958be10a72065",
    "url": "/static/css/chunk-vendors.3ff36de3.css"
  },
  {
    "revision": "8fc945c1945784fd820f",
    "url": "/static/css/compilacao.b83dffc4.css"
  },
  {
    "revision": "0377fca9a4bbe7dea14a",
    "url": "/static/css/construct.475dffe8.css"
  },
  {
    "revision": "5501762945e6bad86732",
    "url": "/static/css/loa.19530300.css"
  },
  {
    "revision": "942025d6ac45441c4828",
    "url": "/static/css/painel.fd83c40d.css"
  },
  {
    "revision": "1a575a4138e5f366474f0e7c5bd614a5",
    "url": "/static/fonts/fa-brands-400.1a575a41.woff"
  },
  {
    "revision": "513aa607d398efaccc559916c3431403",
    "url": "/static/fonts/fa-brands-400.513aa607.ttf"
  },
  {
    "revision": "592643a83b8541edc52063d84c468700",
    "url": "/static/fonts/fa-brands-400.592643a8.eot"
  },
  {
    "revision": "ed311c7a0ade9a75bb3ebf5a7670f31d",
    "url": "/static/fonts/fa-brands-400.ed311c7a.woff2"
  },
  {
    "revision": "766913e6c0088ab8c9f73e18b4127bc4",
    "url": "/static/fonts/fa-regular-400.766913e6.ttf"
  },
  {
    "revision": "b0e2db3b634d1bc3928e127458d993d8",
    "url": "/static/fonts/fa-regular-400.b0e2db3b.eot"
  },
  {
    "revision": "b91d376b8d7646d671cd820950d5f7f1",
    "url": "/static/fonts/fa-regular-400.b91d376b.woff2"
  },
  {
    "revision": "d1d7e3b4c219fde0f7376c6facfd7149",
    "url": "/static/fonts/fa-regular-400.d1d7e3b4.woff"
  },
  {
    "revision": "0c6bfc668a72935760178f91327aed3a",
    "url": "/static/fonts/fa-solid-900.0c6bfc66.eot"
  },
  {
    "revision": "b9625119ce4300f0ef890a8f3234c773",
    "url": "/static/fonts/fa-solid-900.b9625119.ttf"
  },
  {
    "revision": "d745348d289b149026921f197929a893",
    "url": "/static/fonts/fa-solid-900.d745348d.woff"
  },
  {
    "revision": "d824df7eb2e268626a2dd9a6a741ac4e",
    "url": "/static/fonts/fa-solid-900.d824df7e.woff2"
  },
  {
    "revision": "7dff63695e03670336c6802fba347192",
    "url": "/static/img/arrow.png"
  },
  {
    "revision": "0e297f93ffa296cb2bf2782aa94e3268",
    "url": "/static/img/authenticated.png"
  },
  {
    "revision": "f0ce5b4a7afbc34f6a5b5451a18240a1",
    "url": "/static/img/avatar.png"
  },
  {
    "revision": "0fedfc17af66cfcd0beaab4a2beec61d",
    "url": "/static/img/beta.png"
  },
  {
    "revision": "4c35c324fbeb89c16b575c7381f70d6a",
    "url": "/static/img/bg.png"
  },
  {
    "revision": "39bca038c6e5e11e4f7c1e4ee3389c57",
    "url": "/static/img/bg_cmj_topo_menu_box_left.png"
  },
  {
    "revision": "e107ac1f05c9ef2c6c629807be229781",
    "url": "/static/img/bg_cmj_topo_menu_box_right.png"
  },
  {
    "revision": "849c15ec220a24e99aa8506601f41ba9",
    "url": "/static/img/brasao_transp.gif"
  },
  {
    "revision": "bb1e0825d5223704d2c295f4e1d86b91",
    "url": "/static/img/down_arrow_select.jpg"
  },
  {
    "revision": "587404969e0999831266a637b48aea4c",
    "url": "/static/img/etiqueta.png"
  },
  {
    "revision": "1d5619cd804367cefe6da2d79289218a",
    "url": "/static/img/fa-brands-400.1d5619cd.svg"
  },
  {
    "revision": "c5d109be8edd3de0f60eb472bd9ef691",
    "url": "/static/img/fa-regular-400.c5d109be.svg"
  },
  {
    "revision": "37bc7099f6f1ba80236164f22e905837",
    "url": "/static/img/fa-solid-900.37bc7099.svg"
  },
  {
    "revision": "93ba768be99c67b9030dfa2ed3fff325",
    "url": "/static/img/file.png"
  },
  {
    "revision": "1eb0982bb8b20b77fafda393ae98e76b",
    "url": "/static/img/foto_aerea_camara_paisagem.jpg"
  },
  {
    "revision": "6fe0dd25f631b39eb6c052e6e43f8177",
    "url": "/static/img/foto_aerea_camara_retrato.jpg"
  },
  {
    "revision": "cfce175ac693569944dcba9e6c556dcf",
    "url": "/static/img/foto_chao_camara_paisagem.jpg"
  },
  {
    "revision": "ffe462fdcbc1b3fe6c152bbe9f0b3512",
    "url": "/static/img/foto_chao_camara_retrato.jpg"
  },
  {
    "revision": "64400f9f98b710c7fd5fd5fe737fa5da",
    "url": "/static/img/hand-note.png"
  },
  {
    "revision": "02a478243475dc9ba11c7f0915cfeb4b",
    "url": "/static/img/icon_comissoes.png"
  },
  {
    "revision": "40757133ae49b1a803785cd3b4d291d2",
    "url": "/static/img/icon_delete_white.png"
  },
  {
    "revision": "717405792fc232b5e210975822cac408",
    "url": "/static/img/icon_diario_oficial.png"
  },
  {
    "revision": "dbd3da2407bbb56f28b74d0ac573786d",
    "url": "/static/img/icon_facebook64x64.png"
  },
  {
    "revision": "761d394d64ef531b8abf8a9399ce46ff",
    "url": "/static/img/icon_favo.761d394d.svg"
  },
  {
    "revision": "c55a1bc2d99244a4c08aa448f361977b",
    "url": "/static/img/icon_instagram64x64.png"
  },
  {
    "revision": "db910d5dc2b1d30e05766228256eb03d",
    "url": "/static/img/icon_licitacao.png"
  },
  {
    "revision": "69067c48fb437e151a2f90d2290a70ee",
    "url": "/static/img/icon_materia_legislativa.png"
  },
  {
    "revision": "d9d48b974febd617d01b336974c30602",
    "url": "/static/img/icon_mesa_diretora.png"
  },
  {
    "revision": "52266702cd5f7dbdfa8024e799064a52",
    "url": "/static/img/icon_normas_juridicas.png"
  },
  {
    "revision": "d0c2cc179ab932fb24ea6258f61e6157",
    "url": "/static/img/icon_normas_juridicas_destaque.png"
  },
  {
    "revision": "aa171389861a663655fd834079f0d039",
    "url": "/static/img/icon_parlamentares.png"
  },
  {
    "revision": "0558a63d676cc435f2695119e12fdf5f",
    "url": "/static/img/icon_pautas.png"
  },
  {
    "revision": "f182e226a4ff6fe9408b616b02357cf0",
    "url": "/static/img/icon_plenarias.png"
  },
  {
    "revision": "02f6e0c106f20a7c6e21a7b523207f47",
    "url": "/static/img/icon_relatorios.png"
  },
  {
    "revision": "80baf13f86d26f847f3d1b7c7824d4ac",
    "url": "/static/img/icon_save_white.png"
  },
  {
    "revision": "c79840b15ffb49df44967f48807086b3",
    "url": "/static/img/icon_telegram64x64.png"
  },
  {
    "revision": "1d5eeaaa12bce45bbff08db8649e8236",
    "url": "/static/img/icon_transparencia.png"
  },
  {
    "revision": "ef54a640a5c60454a2e7453400bb474f",
    "url": "/static/img/icon_transparencia_prata.png"
  },
  {
    "revision": "2913dd0f6f0cb6715bccef36b0a1e834",
    "url": "/static/img/icon_twitter64x64.png"
  },
  {
    "revision": "aeb805abec46d148aad293ef9abffb79",
    "url": "/static/img/icon_whatsapp64x64.png"
  },
  {
    "revision": "014534399a6fb8befff55baa41e88f40",
    "url": "/static/img/icon_x_twitter.png"
  },
  {
    "revision": "f8e6bc697c257aa4fb5240c7dcbc97c4",
    "url": "/static/img/icon_x_twitter.svg"
  },
  {
    "revision": "c2e9627ea8ba42292971f91003af2490",
    "url": "/static/img/lexml.gif"
  },
  {
    "revision": "91a31efd0faa6d218e52775620e5280e",
    "url": "/static/img/logo.png"
  },
  {
    "revision": "8f99e5ea64db3fcda01b117954e4af6f",
    "url": "/static/img/logo_128.png"
  },
  {
    "revision": "317993f5074301653849e01d7650b1b3",
    "url": "/static/img/logo_cc.png"
  },
  {
    "revision": "06a3dea855d83cb8194e22ab2eabe198",
    "url": "/static/img/logo_cmj_redesocial.jpg"
  },
  {
    "revision": "59f2f9287bac78d247507ee5c5053dea",
    "url": "/static/img/logo_interlegis.png"
  },
  {
    "revision": "09e89b66eeb6647dece0197619aec778",
    "url": "/static/img/logo_portaldocidadao.png"
  },
  {
    "revision": "a1a5cb8ccda80ba8d2e53de044a749a0",
    "url": "/static/img/logo_sic.png"
  },
  {
    "revision": "8fbc3fa26d7f696fed113c2e72419a02",
    "url": "/static/img/manual.png"
  },
  {
    "revision": "296d5d8e05785fd7d04439e18e9ff91d",
    "url": "/static/img/pdf_cabec.jpg"
  },
  {
    "revision": "e86d4f3790dcba9d471b7d6ece42e48c",
    "url": "/static/img/pdf_cabec_margem.jpg"
  },
  {
    "revision": "c0e894ed8b441b6739133c2a7601150d",
    "url": "/static/img/pdf_rodape.jpg"
  },
  {
    "revision": "64679dab3b056be7ac0c73409f963fcb",
    "url": "/static/img/pdf_rodape_margem.jpg"
  },
  {
    "revision": "fb71e48b2330408afac41e0bcfbbd4c0",
    "url": "/static/img/pdflogo.png"
  },
  {
    "revision": "394e657c181354ac1b5c43ce799909a6",
    "url": "/static/img/perfil.1.jpg"
  },
  {
    "revision": "394e657c181354ac1b5c43ce799909a6",
    "url": "/static/img/perfil.jpg"
  },
  {
    "revision": "43b8081d408cea9bc8e27d99fd8636ae",
    "url": "/static/img/perfil.png"
  },
  {
    "revision": "6dc51af6e7a5ac30728639f3cdf62804",
    "url": "/static/img/search-gray.png"
  },
  {
    "revision": "2e90e4927047c60bf57d947fd87a824b",
    "url": "/static/img/search.png"
  },
  {
    "revision": "dbb46e053254b0e6a8fc2488275dd6be",
    "url": "/static/img/search_box_icon36.png"
  },
  {
    "revision": "dbb46e053254b0e6a8fc2488275dd6be",
    "url": "/static/img/search_box_icon36_delete.png"
  },
  {
    "revision": "f44e50fa5d4b59582aefd69db029343f",
    "url": "/static/img/spl_logo.png"
  },
  {
    "revision": "9a0717578fe8e07bbd512ec97725cdc0",
    "url": "/static/img/user.png"
  },
  {
    "revision": "85b802a721dc1e510b25725865a1e5fd",
    "url": "/static/index.html"
  },
  {
    "revision": "49535e7b79d21186b1db",
    "url": "/static/js/app.be2cb96c.js"
  },
  {
    "revision": "563f2d735e2604263813",
    "url": "/static/js/chunk-060d195a.c10ca719.js"
  },
  {
    "revision": "919c2f37e4f0dd94c189",
    "url": "/static/js/chunk-2d0cb66a.01c76142.js"
  },
  {
    "revision": "3d7c309c0ee7cc5ac125",
    "url": "/static/js/chunk-2d216bf1.bc3622b6.js"
  },
  {
    "revision": "29e4c60b46e29c1f0da6",
    "url": "/static/js/chunk-2d21a0bf.c0b04c7b.js"
  },
  {
    "revision": "fdd13f0ae39144aded8e",
    "url": "/static/js/chunk-4dfc392a.1f9cc09d.js"
  },
  {
    "revision": "b0a5e080cc424a3e5aab",
    "url": "/static/js/chunk-522d6fa4.b4062dca.js"
  },
  {
    "revision": "0a37eedddb8f58b53f58",
    "url": "/static/js/chunk-5d5a309a.1865f1e1.js"
  },
  {
    "revision": "70d89936a9118b42c2e2",
    "url": "/static/js/chunk-5fb8b196.8baf0c21.js"
  },
  {
    "revision": "277a3467b32f24b3927d",
    "url": "/static/js/chunk-6f0ff250.b415f80b.js"
  },
  {
    "revision": "f1e65c0f871bb6e67e3f",
    "url": "/static/js/chunk-789e69d2.b638cd0a.js"
  },
  {
    "revision": "bc43edc45efff4503bf2",
    "url": "/static/js/chunk-78b028b8.2e92f39f.js"
  },
  {
    "revision": "4f221c5e7a5d0fb014cf",
    "url": "/static/js/chunk-7a782422.b1fe08b4.js"
  },
  {
    "revision": "45274a22ece734bf993a",
    "url": "/static/js/chunk-f3b7518c.0c80b0ba.js"
  },
  {
    "revision": "cedbbe2958be10a72065",
    "url": "/static/js/chunk-vendors.0e8caecc.js"
  },
  {
    "revision": "8fc945c1945784fd820f",
    "url": "/static/js/compilacao.6a4edeb4.js"
  },
  {
    "revision": "0377fca9a4bbe7dea14a",
    "url": "/static/js/construct.19b05260.js"
  },
  {
    "revision": "a57940c7ace87ec7636c8b98aef7286a",
    "url": "/static/js/dashboard_custom.js"
  },
  {
    "revision": "5501762945e6bad86732",
    "url": "/static/js/loa.cf977957.js"
  },
  {
    "revision": "942025d6ac45441c4828",
    "url": "/static/js/painel.e2c09202.js"
  },
  {
    "revision": "c18a991f9ef0b423adb8b1b132afea6c",
    "url": "/static/js/skins/content/dark/content.css"
  },
  {
    "revision": "38b9cd18bbec1e79964f94f79df8d322",
    "url": "/static/js/skins/content/dark/content.js"
  },
  {
    "revision": "8be098c8a09616b6f37f8ed7c963ebca",
    "url": "/static/js/skins/content/dark/content.min.css"
  },
  {
    "revision": "fdd392b36001c3e0f925e00869fab674",
    "url": "/static/js/skins/content/default/content.css"
  },
  {
    "revision": "f014cdd3dc76c820424ea0c13706b527",
    "url": "/static/js/skins/content/default/content.js"
  },
  {
    "revision": "e7448307845064b6e567dabdf0edd81a",
    "url": "/static/js/skins/content/default/content.min.css"
  },
  {
    "revision": "d6e36fda2726c056c0782b7f0e0d3a33",
    "url": "/static/js/skins/content/document/content.css"
  },
  {
    "revision": "e133bc2114fa6bd3fb9e6404d5858e40",
    "url": "/static/js/skins/content/document/content.js"
  },
  {
    "revision": "6cb27dc9ba941235eb2b074c9cbf7126",
    "url": "/static/js/skins/content/document/content.min.css"
  },
  {
    "revision": "4d9f0e703d7e35ede12e5cc6916ff75b",
    "url": "/static/js/skins/content/tinymce-5-dark/content.css"
  },
  {
    "revision": "445fd0a046091300c16b598738f48267",
    "url": "/static/js/skins/content/tinymce-5-dark/content.js"
  },
  {
    "revision": "4e7d595a3352a317ac5457e1544dd018",
    "url": "/static/js/skins/content/tinymce-5-dark/content.min.css"
  },
  {
    "revision": "fdd392b36001c3e0f925e00869fab674",
    "url": "/static/js/skins/content/tinymce-5/content.css"
  },
  {
    "revision": "97d1c5e4a709a49fd6f89552fc2e5f87",
    "url": "/static/js/skins/content/tinymce-5/content.js"
  },
  {
    "revision": "e7448307845064b6e567dabdf0edd81a",
    "url": "/static/js/skins/content/tinymce-5/content.min.css"
  },
  {
    "revision": "54891f08e9425ba6cfc8285c320f4394",
    "url": "/static/js/skins/content/writer/content.css"
  },
  {
    "revision": "f11cb3b267cb6d8ede6190a1b736e02a",
    "url": "/static/js/skins/content/writer/content.js"
  },
  {
    "revision": "5647767d1db4e7cbfe47ab7510c8aeea",
    "url": "/static/js/skins/content/writer/content.min.css"
  },
  {
    "revision": "a81f21dded3a28cd6a69e058482e9325",
    "url": "/static/js/skins/ui/oxide-dark/content.css"
  },
  {
    "revision": "b27b20c2f358404b2138fb51bd227990",
    "url": "/static/js/skins/ui/oxide-dark/content.inline.css"
  },
  {
    "revision": "cb77d29b0f7f21b50e80c842ba8612df",
    "url": "/static/js/skins/ui/oxide-dark/content.inline.js"
  },
  {
    "revision": "a6c412072a15b50ad031a077d877e678",
    "url": "/static/js/skins/ui/oxide-dark/content.inline.min.css"
  },
  {
    "revision": "c5f12f08e0df261443c0c9b3fe4f790f",
    "url": "/static/js/skins/ui/oxide-dark/content.js"
  },
  {
    "revision": "aa57b3161b164cd73df4db5205e08f4a",
    "url": "/static/js/skins/ui/oxide-dark/content.min.css"
  },
  {
    "revision": "b02cb5429aa20ec4e46aae8b262786f9",
    "url": "/static/js/skins/ui/oxide-dark/skin.css"
  },
  {
    "revision": "c6955fab969ecdb4f259ef05ddc12b94",
    "url": "/static/js/skins/ui/oxide-dark/skin.js"
  },
  {
    "revision": "cde5978275cd657e1c3142fcc0834a62",
    "url": "/static/js/skins/ui/oxide-dark/skin.min.css"
  },
  {
    "revision": "31792aa3530bea8433b3b50c8c38529f",
    "url": "/static/js/skins/ui/oxide-dark/skin.shadowdom.css"
  },
  {
    "revision": "e96d3c218f2b79f82e2c87b6f3f818bb",
    "url": "/static/js/skins/ui/oxide-dark/skin.shadowdom.js"
  },
  {
    "revision": "1448b0502cbc52a71d7b2a5eaa9f3847",
    "url": "/static/js/skins/ui/oxide-dark/skin.shadowdom.min.css"
  },
  {
    "revision": "9d07f566e722dfe95f538778f481c868",
    "url": "/static/js/skins/ui/oxide/content.css"
  },
  {
    "revision": "b27b20c2f358404b2138fb51bd227990",
    "url": "/static/js/skins/ui/oxide/content.inline.css"
  },
  {
    "revision": "de8c1cf867891f83538bd89d07d96358",
    "url": "/static/js/skins/ui/oxide/content.inline.js"
  },
  {
    "revision": "a6c412072a15b50ad031a077d877e678",
    "url": "/static/js/skins/ui/oxide/content.inline.min.css"
  },
  {
    "revision": "989f816397edd4b304da863f48fda91c",
    "url": "/static/js/skins/ui/oxide/content.js"
  },
  {
    "revision": "821a32db5e28e6b996697e2e07626349",
    "url": "/static/js/skins/ui/oxide/content.min.css"
  },
  {
    "revision": "ad61522bcbda78cfaf7c498ec8262940",
    "url": "/static/js/skins/ui/oxide/skin.css"
  },
  {
    "revision": "a76b50e3459064ee98d212963136bd92",
    "url": "/static/js/skins/ui/oxide/skin.js"
  },
  {
    "revision": "4c1369cf6083f903e3216a5124f15290",
    "url": "/static/js/skins/ui/oxide/skin.min.css"
  },
  {
    "revision": "31792aa3530bea8433b3b50c8c38529f",
    "url": "/static/js/skins/ui/oxide/skin.shadowdom.css"
  },
  {
    "revision": "fb3cc71941cdc2e83de399ee39abe36d",
    "url": "/static/js/skins/ui/oxide/skin.shadowdom.js"
  },
  {
    "revision": "1448b0502cbc52a71d7b2a5eaa9f3847",
    "url": "/static/js/skins/ui/oxide/skin.shadowdom.min.css"
  },
  {
    "revision": "88176b46d5b3cef7ed0dce3f9b2e7978",
    "url": "/static/js/skins/ui/tinymce-5-dark/content.css"
  },
  {
    "revision": "b27b20c2f358404b2138fb51bd227990",
    "url": "/static/js/skins/ui/tinymce-5-dark/content.inline.css"
  },
  {
    "revision": "f0eb7e184865f7bc0720ccdc0e172729",
    "url": "/static/js/skins/ui/tinymce-5-dark/content.inline.js"
  },
  {
    "revision": "a6c412072a15b50ad031a077d877e678",
    "url": "/static/js/skins/ui/tinymce-5-dark/content.inline.min.css"
  },
  {
    "revision": "ed1e7b7415d372ec3d6e01781b67e5fd",
    "url": "/static/js/skins/ui/tinymce-5-dark/content.js"
  },
  {
    "revision": "99f63ebfa6fa0e68c3a37d941d385151",
    "url": "/static/js/skins/ui/tinymce-5-dark/content.min.css"
  },
  {
    "revision": "d0da2845486c4b75e1063cfbceb87e96",
    "url": "/static/js/skins/ui/tinymce-5-dark/skin.css"
  },
  {
    "revision": "9999bcdaef9d2d6647454dc92ce9810d",
    "url": "/static/js/skins/ui/tinymce-5-dark/skin.js"
  },
  {
    "revision": "259ccbe515d9596d0a839b67d59e1e66",
    "url": "/static/js/skins/ui/tinymce-5-dark/skin.min.css"
  },
  {
    "revision": "31792aa3530bea8433b3b50c8c38529f",
    "url": "/static/js/skins/ui/tinymce-5-dark/skin.shadowdom.css"
  },
  {
    "revision": "eb127cec1c96aebc630b4f9f5efcbf7e",
    "url": "/static/js/skins/ui/tinymce-5-dark/skin.shadowdom.js"
  },
  {
    "revision": "1448b0502cbc52a71d7b2a5eaa9f3847",
    "url": "/static/js/skins/ui/tinymce-5-dark/skin.shadowdom.min.css"
  },
  {
    "revision": "9d07f566e722dfe95f538778f481c868",
    "url": "/static/js/skins/ui/tinymce-5/content.css"
  },
  {
    "revision": "b27b20c2f358404b2138fb51bd227990",
    "url": "/static/js/skins/ui/tinymce-5/content.inline.css"
  },
  {
    "revision": "d3e81b6cf4bd844128775cc04035dcef",
    "url": "/static/js/skins/ui/tinymce-5/content.inline.js"
  },
  {
    "revision": "a6c412072a15b50ad031a077d877e678",
    "url": "/static/js/skins/ui/tinymce-5/content.inline.min.css"
  },
  {
    "revision": "c6f4441c116126ef1f299ccfdcbc733d",
    "url": "/static/js/skins/ui/tinymce-5/content.js"
  },
  {
    "revision": "821a32db5e28e6b996697e2e07626349",
    "url": "/static/js/skins/ui/tinymce-5/content.min.css"
  },
  {
    "revision": "349974f70449a482750f5181a4fa7455",
    "url": "/static/js/skins/ui/tinymce-5/skin.css"
  },
  {
    "revision": "2da33d74c83d0c128ea2a2c55a8d80b6",
    "url": "/static/js/skins/ui/tinymce-5/skin.js"
  },
  {
    "revision": "1e616f9e05fac9163d97a9b296dc84fd",
    "url": "/static/js/skins/ui/tinymce-5/skin.min.css"
  },
  {
    "revision": "31792aa3530bea8433b3b50c8c38529f",
    "url": "/static/js/skins/ui/tinymce-5/skin.shadowdom.css"
  },
  {
    "revision": "7d0e89599f3017f7e3941b47f71afee3",
    "url": "/static/js/skins/ui/tinymce-5/skin.shadowdom.js"
  },
  {
    "revision": "1448b0502cbc52a71d7b2a5eaa9f3847",
    "url": "/static/js/skins/ui/tinymce-5/skin.shadowdom.min.css"
  },
  {
    "revision": "a0f2247a0047149e2a62a059c7319a6e",
    "url": "/static/manifest.json"
  },
  {
    "revision": "3d798458ee267f228251ca2b111181ba",
    "url": "/static/robots.txt"
  },
  {
    "revision": "70d558986a2f1b45a5b49f522b9bacb0",
    "url": "/static/service-worker.js"
  }
]);