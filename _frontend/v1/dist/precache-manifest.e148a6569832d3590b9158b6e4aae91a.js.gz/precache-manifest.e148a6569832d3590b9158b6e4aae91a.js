self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d44ac6d2a43c55274f04d4c050ed0692",
    "url": "/static/brasao/brasao_1024.png"
  },
  {
    "revision": "8f99e5ea64db3fcda01b117954e4af6f",
    "url": "/static/brasao/brasao_128.png"
  },
  {
    "revision": "6c307cb29fb97f80facd4199fb46d45f",
    "url": "/static/brasao/brasao_256.png"
  },
  {
    "revision": "2faeef56500a910abf40dd2d98ef9a99",
    "url": "/static/brasao/brasao_32.png"
  },
  {
    "revision": "7f74a84703400cee7e6807673fd939f8",
    "url": "/static/brasao/brasao_512.png"
  },
  {
    "revision": "f7b796ce23a9c65a82e199e56efded11",
    "url": "/static/brasao/brasao_64.png"
  },
  {
    "revision": "4c5185ea96c8723155d1",
    "url": "/static/css/app.f016e1b2.css"
  },
  {
    "revision": "a76d9eac28e63e202bf7",
    "url": "/static/css/chunk-0951e867.3ca8326a.css"
  },
  {
    "revision": "5dbc4f28a47a2747ca50",
    "url": "/static/css/chunk-227d0a6e.79a56ae1.css"
  },
  {
    "revision": "8ef3ee573ef02f31b400",
    "url": "/static/css/chunk-7c767211.b9145c14.css"
  },
  {
    "revision": "7b8c9ae7975c9a7d2fbb",
    "url": "/static/css/chunk-f11218b8.707facdf.css"
  },
  {
    "revision": "f8f1f0f27a0fb1aba045",
    "url": "/static/css/chunk-vendors.1e5351fa.css"
  },
  {
    "revision": "fa5b2b266f7863fb4c24",
    "url": "/static/css/compilacao.2a3ce346.css"
  },
  {
    "revision": "e05b0e55abdc55310ae2",
    "url": "/static/css/construct.6cb1e7d1.css"
  },
  {
    "revision": "68920a17224f54fb4465",
    "url": "/static/css/painel.fd83c40d.css"
  },
  {
    "revision": "085b1dd8427dbeff10bd55410915a3f6",
    "url": "/static/fonts/fa-brands-400.085b1dd8.ttf"
  },
  {
    "revision": "0fabb6606be4c45acfeedd115d0caca4",
    "url": "/static/fonts/fa-brands-400.0fabb660.eot"
  },
  {
    "revision": "cac68c831145804808381a7032fdc7c2",
    "url": "/static/fonts/fa-brands-400.cac68c83.woff2"
  },
  {
    "revision": "dc0bd022735ed218df547742a1b2f172",
    "url": "/static/fonts/fa-brands-400.dc0bd022.woff"
  },
  {
    "revision": "05b53beb21e3ef13d28244545977152d",
    "url": "/static/fonts/fa-regular-400.05b53beb.woff"
  },
  {
    "revision": "1a78af4105d4d56e6c34f76dc70bf1bc",
    "url": "/static/fonts/fa-regular-400.1a78af41.ttf"
  },
  {
    "revision": "3a3398a6ef60fc64eacf45665958342e",
    "url": "/static/fonts/fa-regular-400.3a3398a6.woff2"
  },
  {
    "revision": "ad3a7c0d77e09602f4ab73db3660ffd8",
    "url": "/static/fonts/fa-regular-400.ad3a7c0d.eot"
  },
  {
    "revision": "781e85bb50c8e8301c30de56b31b1f04",
    "url": "/static/fonts/fa-solid-900.781e85bb.ttf"
  },
  {
    "revision": "89bd2e38475e441a5cd70f663f921d61",
    "url": "/static/fonts/fa-solid-900.89bd2e38.eot"
  },
  {
    "revision": "c500da19d776384ba69573ae6fe274e7",
    "url": "/static/fonts/fa-solid-900.c500da19.woff2"
  },
  {
    "revision": "ee09ad7553b8ad3d81150d609d5341a0",
    "url": "/static/fonts/fa-solid-900.ee09ad75.woff"
  },
  {
    "revision": "7dff63695e03670336c6802fba347192",
    "url": "/static/img/arrow.png"
  },
  {
    "revision": "0e297f93ffa296cb2bf2782aa94e3268",
    "url": "/static/img/authenticated.png"
  },
  {
    "revision": "f0ce5b4a7afbc34f6a5b5451a18240a1",
    "url": "/static/img/avatar.png"
  },
  {
    "revision": "0fedfc17af66cfcd0beaab4a2beec61d",
    "url": "/static/img/beta.png"
  },
  {
    "revision": "4c35c324fbeb89c16b575c7381f70d6a",
    "url": "/static/img/bg.png"
  },
  {
    "revision": "39bca038c6e5e11e4f7c1e4ee3389c57",
    "url": "/static/img/bg_cmj_topo_menu_box_left.png"
  },
  {
    "revision": "e107ac1f05c9ef2c6c629807be229781",
    "url": "/static/img/bg_cmj_topo_menu_box_right.png"
  },
  {
    "revision": "849c15ec220a24e99aa8506601f41ba9",
    "url": "/static/img/brasao_transp.gif"
  },
  {
    "revision": "bb1e0825d5223704d2c295f4e1d86b91",
    "url": "/static/img/down_arrow_select.jpg"
  },
  {
    "revision": "587404969e0999831266a637b48aea4c",
    "url": "/static/img/etiqueta.png"
  },
  {
    "revision": "ccfdb9dc442be0c629d331e94497428b",
    "url": "/static/img/fa-brands-400.ccfdb9dc.svg"
  },
  {
    "revision": "e75dfd904d366a2560c63c23cfc98ef8",
    "url": "/static/img/fa-regular-400.e75dfd90.svg"
  },
  {
    "revision": "03ba7cb710104df27f1c9c46d64bee4e",
    "url": "/static/img/fa-solid-900.03ba7cb7.svg"
  },
  {
    "revision": "93ba768be99c67b9030dfa2ed3fff325",
    "url": "/static/img/file.png"
  },
  {
    "revision": "64400f9f98b710c7fd5fd5fe737fa5da",
    "url": "/static/img/hand-note.png"
  },
  {
    "revision": "02a478243475dc9ba11c7f0915cfeb4b",
    "url": "/static/img/icon_comissoes.png"
  },
  {
    "revision": "40757133ae49b1a803785cd3b4d291d2",
    "url": "/static/img/icon_delete_white.png"
  },
  {
    "revision": "717405792fc232b5e210975822cac408",
    "url": "/static/img/icon_diario_oficial.png"
  },
  {
    "revision": "dbd3da2407bbb56f28b74d0ac573786d",
    "url": "/static/img/icon_facebook64x64.png"
  },
  {
    "revision": "c55a1bc2d99244a4c08aa448f361977b",
    "url": "/static/img/icon_instagram64x64.png"
  },
  {
    "revision": "db910d5dc2b1d30e05766228256eb03d",
    "url": "/static/img/icon_licitacao.png"
  },
  {
    "revision": "69067c48fb437e151a2f90d2290a70ee",
    "url": "/static/img/icon_materia_legislativa.png"
  },
  {
    "revision": "d9d48b974febd617d01b336974c30602",
    "url": "/static/img/icon_mesa_diretora.png"
  },
  {
    "revision": "52266702cd5f7dbdfa8024e799064a52",
    "url": "/static/img/icon_normas_juridicas.png"
  },
  {
    "revision": "d0c2cc179ab932fb24ea6258f61e6157",
    "url": "/static/img/icon_normas_juridicas_destaque.png"
  },
  {
    "revision": "aa171389861a663655fd834079f0d039",
    "url": "/static/img/icon_parlamentares.png"
  },
  {
    "revision": "0558a63d676cc435f2695119e12fdf5f",
    "url": "/static/img/icon_pautas.png"
  },
  {
    "revision": "f182e226a4ff6fe9408b616b02357cf0",
    "url": "/static/img/icon_plenarias.png"
  },
  {
    "revision": "02f6e0c106f20a7c6e21a7b523207f47",
    "url": "/static/img/icon_relatorios.png"
  },
  {
    "revision": "80baf13f86d26f847f3d1b7c7824d4ac",
    "url": "/static/img/icon_save_white.png"
  },
  {
    "revision": "1d5eeaaa12bce45bbff08db8649e8236",
    "url": "/static/img/icon_transparencia.png"
  },
  {
    "revision": "2913dd0f6f0cb6715bccef36b0a1e834",
    "url": "/static/img/icon_twitter64x64.png"
  },
  {
    "revision": "aeb805abec46d148aad293ef9abffb79",
    "url": "/static/img/icon_whatsapp64x64.png"
  },
  {
    "revision": "c2e9627ea8ba42292971f91003af2490",
    "url": "/static/img/lexml.gif"
  },
  {
    "revision": "91a31efd0faa6d218e52775620e5280e",
    "url": "/static/img/logo.png"
  },
  {
    "revision": "8f99e5ea64db3fcda01b117954e4af6f",
    "url": "/static/img/logo_128.png"
  },
  {
    "revision": "317993f5074301653849e01d7650b1b3",
    "url": "/static/img/logo_cc.png"
  },
  {
    "revision": "06a3dea855d83cb8194e22ab2eabe198",
    "url": "/static/img/logo_cmj_redesocial.jpg"
  },
  {
    "revision": "59f2f9287bac78d247507ee5c5053dea",
    "url": "/static/img/logo_interlegis.png"
  },
  {
    "revision": "a1a5cb8ccda80ba8d2e53de044a749a0",
    "url": "/static/img/logo_sic.png"
  },
  {
    "revision": "8fbc3fa26d7f696fed113c2e72419a02",
    "url": "/static/img/manual.png"
  },
  {
    "revision": "296d5d8e05785fd7d04439e18e9ff91d",
    "url": "/static/img/pdf_cabec.jpg"
  },
  {
    "revision": "c0e894ed8b441b6739133c2a7601150d",
    "url": "/static/img/pdf_rodape.jpg"
  },
  {
    "revision": "fb71e48b2330408afac41e0bcfbbd4c0",
    "url": "/static/img/pdflogo.png"
  },
  {
    "revision": "394e657c181354ac1b5c43ce799909a6",
    "url": "/static/img/perfil.1.jpg"
  },
  {
    "revision": "394e657c181354ac1b5c43ce799909a6",
    "url": "/static/img/perfil.jpg"
  },
  {
    "revision": "43b8081d408cea9bc8e27d99fd8636ae",
    "url": "/static/img/perfil.png"
  },
  {
    "revision": "6dc51af6e7a5ac30728639f3cdf62804",
    "url": "/static/img/search-gray.png"
  },
  {
    "revision": "2e90e4927047c60bf57d947fd87a824b",
    "url": "/static/img/search.png"
  },
  {
    "revision": "dbb46e053254b0e6a8fc2488275dd6be",
    "url": "/static/img/search_box_icon36.png"
  },
  {
    "revision": "dbb46e053254b0e6a8fc2488275dd6be",
    "url": "/static/img/search_box_icon36_delete.png"
  },
  {
    "revision": "9a0717578fe8e07bbd512ec97725cdc0",
    "url": "/static/img/user.png"
  },
  {
    "revision": "d974fafeab4b82d62c5cfeb7d5c00293",
    "url": "/static/index.html"
  },
  {
    "revision": "4c5185ea96c8723155d1",
    "url": "/static/js/app.f65fbab4.js"
  },
  {
    "revision": "a76d9eac28e63e202bf7",
    "url": "/static/js/chunk-0951e867.170fe06d.js"
  },
  {
    "revision": "5dbc4f28a47a2747ca50",
    "url": "/static/js/chunk-227d0a6e.649162dd.js"
  },
  {
    "revision": "a91a0b2240ef46c007c7",
    "url": "/static/js/chunk-2d0c4a82.61dd9bcb.js"
  },
  {
    "revision": "8ef3ee573ef02f31b400",
    "url": "/static/js/chunk-7c767211.0366f048.js"
  },
  {
    "revision": "7b8c9ae7975c9a7d2fbb",
    "url": "/static/js/chunk-f11218b8.81d90024.js"
  },
  {
    "revision": "f8f1f0f27a0fb1aba045",
    "url": "/static/js/chunk-vendors.f2d36a9c.js"
  },
  {
    "revision": "fa5b2b266f7863fb4c24",
    "url": "/static/js/compilacao.ea406608.js"
  },
  {
    "revision": "e05b0e55abdc55310ae2",
    "url": "/static/js/construct.a654412e.js"
  },
  {
    "revision": "68920a17224f54fb4465",
    "url": "/static/js/painel.5fec57b6.js"
  },
  {
    "revision": "7516fc313b953a9501c3ae0c58933f63",
    "url": "/static/manifest.json"
  },
  {
    "revision": "5db7f7f9589fb1173f80593d7de83f59",
    "url": "/static/robots.txt"
  },
  {
    "revision": "a86f9f2ebe3931d7b46e266c05625689",
    "url": "/static/service-worker.js"
  }
]);