self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d7148dfcfdd06203fae8",
    "url": "/static/css/app.c5c1cd10.css"
  },
  {
    "revision": "717f4c13dcd9e6d29ec7",
    "url": "/static/css/chunk-0951e867.e84c3ec9.css"
  },
  {
    "revision": "95edb603bf46eb5050e9",
    "url": "/static/css/chunk-227d0a6e.79a56ae1.css"
  },
  {
    "revision": "ab8980c55e434177407d",
    "url": "/static/css/chunk-7c767211.b9145c14.css"
  },
  {
    "revision": "db7e4b1cb718cfbc6b63",
    "url": "/static/css/chunk-f11218b8.707facdf.css"
  },
  {
    "revision": "a3d9944ea50c500249d3",
    "url": "/static/css/chunk-vendors.44de1e75.css"
  },
  {
    "revision": "e4415da0feffcd748b07",
    "url": "/static/css/compilacao.2fd128f7.css"
  },
  {
    "revision": "681a07a42c71742c974a",
    "url": "/static/css/construct.6cb1e7d1.css"
  },
  {
    "revision": "68920a17224f54fb4465",
    "url": "/static/css/painel.fd83c40d.css"
  },
  {
    "revision": "8300bd7f30e0a313c1d772b49d96cb8e",
    "url": "/static/fonts/fa-brands-400.8300bd7f.ttf"
  },
  {
    "revision": "ad527cc5ec23d6da66e8a1d6772ea6d3",
    "url": "/static/fonts/fa-brands-400.ad527cc5.woff"
  },
  {
    "revision": "e2ca6541bff3a3e9f4799ee327b28c58",
    "url": "/static/fonts/fa-brands-400.e2ca6541.eot"
  },
  {
    "revision": "f075c50f89795e4cdb4d45b51f1a6800",
    "url": "/static/fonts/fa-brands-400.f075c50f.woff2"
  },
  {
    "revision": "3c6879c4f342203d099bdd66dce6d396",
    "url": "/static/fonts/fa-regular-400.3c6879c4.woff"
  },
  {
    "revision": "49f00693b0e5d45097832ef5ea1bc541",
    "url": "/static/fonts/fa-regular-400.49f00693.ttf"
  },
  {
    "revision": "4a74738e7728e93c4394b8604081da62",
    "url": "/static/fonts/fa-regular-400.4a74738e.woff2"
  },
  {
    "revision": "b01516c1808be557667befec76cd6318",
    "url": "/static/fonts/fa-regular-400.b01516c1.eot"
  },
  {
    "revision": "205f07b3883c484f27f40d21a92950d4",
    "url": "/static/fonts/fa-solid-900.205f07b3.ttf"
  },
  {
    "revision": "4451e1d86df7491dd874f2c41eee1053",
    "url": "/static/fonts/fa-solid-900.4451e1d8.woff"
  },
  {
    "revision": "8ac3167427b1d5d2967646bd8f7a0587",
    "url": "/static/fonts/fa-solid-900.8ac31674.eot"
  },
  {
    "revision": "8e1ed89b6ccb8ce41faf5cb672677105",
    "url": "/static/fonts/fa-solid-900.8e1ed89b.woff2"
  },
  {
    "revision": "2f12242375edd68e9013ecfb59c672e9",
    "url": "/static/img/fa-brands-400.2f122423.svg"
  },
  {
    "revision": "3602b7e8b2cb1462b0bef9738757ef8a",
    "url": "/static/img/fa-regular-400.3602b7e8.svg"
  },
  {
    "revision": "664de3932dd6291b4b8a8c0ddbcb4c61",
    "url": "/static/img/fa-solid-900.664de393.svg"
  },
  {
    "revision": "54129e655e5e6896dca39e7bb5e6b736",
    "url": "/static/index.html"
  },
  {
    "revision": "d7148dfcfdd06203fae8",
    "url": "/static/js/app.b5ad6646.js"
  },
  {
    "revision": "717f4c13dcd9e6d29ec7",
    "url": "/static/js/chunk-0951e867.adb7116c.js"
  },
  {
    "revision": "95edb603bf46eb5050e9",
    "url": "/static/js/chunk-227d0a6e.1edeca02.js"
  },
  {
    "revision": "dcb63a10a10dd4a306cd",
    "url": "/static/js/chunk-2d0c4a82.c6ec3246.js"
  },
  {
    "revision": "ab8980c55e434177407d",
    "url": "/static/js/chunk-7c767211.3a230ac7.js"
  },
  {
    "revision": "db7e4b1cb718cfbc6b63",
    "url": "/static/js/chunk-f11218b8.ed06126f.js"
  },
  {
    "revision": "a3d9944ea50c500249d3",
    "url": "/static/js/chunk-vendors.4321ec3c.js"
  },
  {
    "revision": "e4415da0feffcd748b07",
    "url": "/static/js/compilacao.ea406608.js"
  },
  {
    "revision": "681a07a42c71742c974a",
    "url": "/static/js/construct.61165dbd.js"
  },
  {
    "revision": "68920a17224f54fb4465",
    "url": "/static/js/painel.5fec57b6.js"
  },
  {
    "revision": "abdd83f838fac3428c028294f27efc4e",
    "url": "/static/js/skins/content/dark/content.css"
  },
  {
    "revision": "4c0b8cf274d116c2ff8b3f1c7cfaf9d3",
    "url": "/static/js/skins/content/dark/content.min.css"
  },
  {
    "revision": "db31e42bcf1c9c26eb3c9281816a3b33",
    "url": "/static/js/skins/content/default/content.css"
  },
  {
    "revision": "5022f9908e1f0680cdc3ad293816bd13",
    "url": "/static/js/skins/content/default/content.min.css"
  },
  {
    "revision": "24d66dddf2faa9f48de40df30ae8f1fc",
    "url": "/static/js/skins/content/document/content.css"
  },
  {
    "revision": "0ccaf40378ed037f42d01279f625793d",
    "url": "/static/js/skins/content/document/content.min.css"
  },
  {
    "revision": "3cd6fb97c8178ed816ce946d8b601ffa",
    "url": "/static/js/skins/content/writer/content.css"
  },
  {
    "revision": "856c1120d71e64f227e546a9406587f6",
    "url": "/static/js/skins/content/writer/content.min.css"
  },
  {
    "revision": "b2e1de76382cca41805ff9de79da4bdb",
    "url": "/static/js/skins/ui/oxide-dark/content.css"
  },
  {
    "revision": "02b37a107b5ae121955c43bb4efee57f",
    "url": "/static/js/skins/ui/oxide-dark/content.inline.css"
  },
  {
    "revision": "ce5777f78c423d92c076e5f60bed168b",
    "url": "/static/js/skins/ui/oxide-dark/content.inline.min.css"
  },
  {
    "revision": "9bf88986ca27fef8c399b7c35170309c",
    "url": "/static/js/skins/ui/oxide-dark/content.min.css"
  },
  {
    "revision": "e84062c0d71bace6637586be7c2590d3",
    "url": "/static/js/skins/ui/oxide-dark/content.mobile.css"
  },
  {
    "revision": "411c2608b6be78849a76c0ed14200234",
    "url": "/static/js/skins/ui/oxide-dark/content.mobile.min.css"
  },
  {
    "revision": "baecf466c40e709e7ffdbc935fc0813a",
    "url": "/static/js/skins/ui/oxide-dark/fonts/tinymce-mobile.woff"
  },
  {
    "revision": "41cd5c63b189f1a96823b083c4e4cbf1",
    "url": "/static/js/skins/ui/oxide-dark/skin.css"
  },
  {
    "revision": "41d9c25f1e205ce64fa435d1e8504bf0",
    "url": "/static/js/skins/ui/oxide-dark/skin.min.css"
  },
  {
    "revision": "338b06826c0e8a681688fc195dbb72b1",
    "url": "/static/js/skins/ui/oxide-dark/skin.mobile.css"
  },
  {
    "revision": "4fdf33191102d7a24a5bf0639040d128",
    "url": "/static/js/skins/ui/oxide-dark/skin.mobile.min.css"
  },
  {
    "revision": "6bb06cca1c5dcc257a5eccfe690f6aca",
    "url": "/static/js/skins/ui/oxide-dark/skin.shadowdom.css"
  },
  {
    "revision": "716eed34383df77dbb9ac01b3b72fd05",
    "url": "/static/js/skins/ui/oxide-dark/skin.shadowdom.min.css"
  },
  {
    "revision": "3f8e5ab03a1912508dcc153aee24cd03",
    "url": "/static/js/skins/ui/oxide/content.css"
  },
  {
    "revision": "02b37a107b5ae121955c43bb4efee57f",
    "url": "/static/js/skins/ui/oxide/content.inline.css"
  },
  {
    "revision": "ce5777f78c423d92c076e5f60bed168b",
    "url": "/static/js/skins/ui/oxide/content.inline.min.css"
  },
  {
    "revision": "ee807042b61ee69a8db0755b70536fbc",
    "url": "/static/js/skins/ui/oxide/content.min.css"
  },
  {
    "revision": "e84062c0d71bace6637586be7c2590d3",
    "url": "/static/js/skins/ui/oxide/content.mobile.css"
  },
  {
    "revision": "411c2608b6be78849a76c0ed14200234",
    "url": "/static/js/skins/ui/oxide/content.mobile.min.css"
  },
  {
    "revision": "baecf466c40e709e7ffdbc935fc0813a",
    "url": "/static/js/skins/ui/oxide/fonts/tinymce-mobile.woff"
  },
  {
    "revision": "384c8c3faba0ccd58cc04b829b6ad5c4",
    "url": "/static/js/skins/ui/oxide/skin.css"
  },
  {
    "revision": "9f093ad3c1114144e4537cc8b24677ee",
    "url": "/static/js/skins/ui/oxide/skin.min.css"
  },
  {
    "revision": "338b06826c0e8a681688fc195dbb72b1",
    "url": "/static/js/skins/ui/oxide/skin.mobile.css"
  },
  {
    "revision": "4fdf33191102d7a24a5bf0639040d128",
    "url": "/static/js/skins/ui/oxide/skin.mobile.min.css"
  },
  {
    "revision": "6bb06cca1c5dcc257a5eccfe690f6aca",
    "url": "/static/js/skins/ui/oxide/skin.shadowdom.css"
  },
  {
    "revision": "716eed34383df77dbb9ac01b3b72fd05",
    "url": "/static/js/skins/ui/oxide/skin.shadowdom.min.css"
  },
  {
    "revision": "7516fc313b953a9501c3ae0c58933f63",
    "url": "/static/manifest.json"
  }
]);